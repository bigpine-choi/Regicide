"""Read-only paired-run audit, independent of the experiment driver.

Uses python-chess only for legal replay and PGN validation. It does not search,
change production sources, import the driver, or overwrite raw match evidence.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import subprocess

import chess
import chess.pgn

SCHEMA = "regicide.sparring-close-independent-audit.v1"
SOURCE = "local_stockfish_referee"
POLICIES = ("regicide-stockfish-referee-v1", "regicide-stockfish-referee-v2", "regicide-stockfish-referee-v3")
EXPECTED_DRIVER_SHA = "a8428482e59b326d3ed59e70bcc844161492a41665286c859074e107f85fbf26"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def finite_cp(row):
    return row.get("status") == "exact" and type(row.get("cp_white")) is int


def percentile(values, share):
    return sorted(values)[max(0, math.ceil(len(values) * share) - 1)] if values else None


def _pv(board, ucis, first, label):
    require(isinstance(ucis, (list, tuple)) and 0 < len(ucis) <= 128 and ucis[0] == first, label + ": PV root")
    replay = board.copy(stack=True)
    for uci in ucis:
        require(isinstance(uci, str), label + ": malformed UCI")
        move = chess.Move.from_uci(uci)
        require(move in replay.legal_moves, label + ": illegal PV")
        replay.push(move)
    return replay


def native_line(board, value, uci, label):
    require(isinstance(value, dict) and value.get("uci") == uci, label + ": missing native line")
    sign = 1 if board.turn else -1
    require(type(value.get("depth")) is int and 4 <= value["depth"] <= 256, label + ": native depth")
    require(type(value.get("cp")) is int and abs(value["cp"]) <= 100000
            and type(value.get("cp_white")) is int and value["cp_white"] == sign * value["cp"], label + ": native score POV")
    require(value.get("pov") == ("white" if board.turn else "black"), label + ": native side")
    require(value.get("mate") is None and value.get("mate_white") is None
            and value.get("bound", "exact") == value.get("score_bound", "exact") == "exact"
            and not value.get("lowerbound") and not value.get("upperbound")
            and type(value.get("multipv", 1)) is int and value.get("multipv", 1) == 1, label + ": bounded/mate native evidence")
    for key in ("fen", "before_fen", "source_fen"):
        require(key not in value or value[key] == board.fen(en_passant="fen"), label + ": native context")
    require(not _pv(board, value.get("pv_uci"), uci, label).is_checkmate(), label + ": finite score with mate PV")
    return value


def _line_equal(first, second):
    return all(first.get(key) == second.get(key) for key in ("uci", "pv_uci", "depth", "cp", "cp_white", "pov"))


def raw_native_final(raw, final):
    require(isinstance(raw, dict) and type(raw.get("depth")) is int and type(raw.get("cp")) is int
            and raw["depth"] == final["depth"] and raw["cp"] == final["cp"]
            and raw.get("mate") is None and raw.get("mate_white") is None
            and raw.get("bound", "exact") == raw.get("score_bound", "exact") == "exact"
            and not raw.get("lowerbound") and not raw.get("upperbound"), "native raw final contradicts completed line")


def individual_native_proof(board, original, referee, row):
    uci, proof, origin = row["uci"], row["native_evidence"], row["origin"]
    require(origin in ("partial_probe", "shallow_discovery")
            and proof.get("validation") == "individual_native_completed_depth; no baseline CP comparison"
            and proof.get("native_comparison_available") is False, "individual line mislabeled as common-depth comparison")
    common = native_line(board, proof.get("line"), uci, "individual native line")
    final = native_line(board, proof.get("completed_final_line"), uci, "individual completed final")
    require(final["depth"] >= common["depth"] and (final["depth"] != common["depth"] or final["cp"] == common["cp"]), "individual final completion mismatch")
    require(proof.get("baseline") == original.get("baseline"), "individual baseline context changed")
    require(isinstance(proof.get("naturalness"), dict) and proof["naturalness"].get("admitted") is True, "individual naturalness absent")
    if origin == "partial_probe":
        require(_line_equal(common, final) and proof.get("original_reason") == "no_common_depth", "partial line provenance")
        matches = [probe for probe in original.get("probes", []) if isinstance(probe, dict)
                   and probe.get("uci") == uci and probe.get("admitted") is False
                   and probe.get("reason") == "no_common_depth" and probe.get("error") is None
                   and probe.get("naturalness") == proof["naturalness"]
                   and _line_equal(probe.get("candidate_final", {}), common)]
        require(matches, "partial candidate absent from original native incomplete comparison")
        for probe in matches:
            raw_native_final(probe.get("candidate_final_raw"), common)
    else:
        require(common["depth"] == 4 and 8 <= len(board.move_stack) < 40, "shallow discovery depth/phase")
        require(not original.get("resource_guard", {}).get("active") and not original.get("analysis_only"), "discovery bypassed native resource guard")
        discovery = referee.get("native_discovery")
        require(isinstance(discovery, dict) and discovery.get("origin") == "native_root_exclusion_depth4"
                and discovery.get("reason") == "native_candidates_discovered" and discovery.get("discard_engine") is False, "discovery failed/cancelled evidence used")
        context = discovery.get("context", {})
        require(context.get("before_fen") == board.fen(en_passant="fen")
                and context.get("history_uci") == [move.uci() for move in board.move_stack]
                and context.get("pov") == ("white" if board.turn else "black"), "discovery context mismatch")
        require(type(discovery.get("budget_ms")) is int and 1 <= discovery["budget_ms"] <= 600
                and type(discovery.get("searches")) is int and 1 <= discovery["searches"] <= 3
                and isinstance(discovery.get("allocated_ms"), (int, float)) and 0 < discovery["allocated_ms"] <= discovery["budget_ms"]
                and isinstance(discovery.get("elapsed_ms"), (int, float)) and 0 <= discovery["elapsed_ms"] <= discovery["budget_ms"] + 100,
                "discovery allocation/watchdog boundary")
        candidates = discovery.get("native_candidates")
        require(isinstance(candidates, list) and 1 <= len(candidates) <= discovery["searches"]
                and len({candidate.get("uci") for candidate in candidates}) == len(candidates), "discovery result count/duplicates")
        matches = [candidate for candidate in candidates if candidate.get("uci") == uci
                   and candidate.get("origin") == "shallow_discovery" and candidate.get("source") == "regicide_native_depth4_discovery"
                   and candidate.get("naturalness") == proof["naturalness"]
                   and _line_equal(candidate.get("line", {}), common)
                   and _line_equal(candidate.get("completed_final_line", {}), final)]
        require(matches, "shallow candidate absent from native discovery result")
    return common, final


def native_pool(board, decision, referee):
    original = decision.get("regicide_proposal", {})
    baseline, proposal = original.get("baseline_uci"), original.get("selected_uci")
    require(original.get("before_fen") == board.fen(en_passant="fen")
            and original.get("history_uci") == [move.uci() for move in board.move_stack], "pool original context")
    pool = referee.get("native_pool")
    require(isinstance(pool, list) and 1 <= len(pool) <= 4, "native pool size")
    require(len({row.get("uci") for row in pool}) == len(pool), "native pool duplicates")
    choices = [baseline] if baseline == proposal else [baseline, proposal]
    require([row.get("uci") for row in pool[:len(choices)]] == choices, "original choices not first in pool")
    extras = {}
    for index, row in enumerate(pool):
        uci, proof = row.get("uci"), row.get("native_evidence")
        require(chess.Move.from_uci(uci) in board.legal_moves, "illegal native-pool move")
        require(isinstance(proof, dict) and proof.get("before_fen") == board.fen(en_passant="fen")
                and proof.get("history_uci") == original["history_uci"] and proof.get("policy") == original.get("policy")
                and proof.get("pov") == ("white" if board.turn else "black"), "pool proof context")
        if index < len(choices):
            require(row.get("origin") == ("baseline" if index == 0 else "proposal")
                    and proof.get("validation") == "host_receipt_legal_choice_only", "original pool provenance")
            continue
        if row.get("origin") in ("partial_probe", "shallow_discovery"):
            require(referee.get("policy") == POLICIES[2], "individual native origin outside v3")
            common, final = individual_native_proof(board, original, referee, row)
            extras[uci] = {"common": common, "final": final, "individual": True}
            continue
        require(row.get("origin") == "verified_probe" and proof.get("validation") == "same_context_native_completed_depth_probe", "expanded pool provenance")
        base = native_line(board, original.get("baseline"), baseline, "pool original baseline")
        require(_line_equal(native_line(board, proof.get("baseline"), baseline, "pool baseline"), base), "pool baseline differs from own receipt")
        for key in ("actual_reference_depth", "verification_depth", "compared_depth"):
            value = original.get(key)
            require(value is None or type(value) is int and value == base["depth"], "original reference depth inconsistent")
        common = native_line(board, proof.get("candidate_compared"), uci, "pool common")
        final = native_line(board, proof.get("candidate_final"), uci, "pool final")
        require(type(proof.get("compared_depth")) is int and common["depth"] == proof["compared_depth"] == base["depth"]
                and final["depth"] >= common["depth"]
                and (final["depth"] != common["depth"] or final["cp"] == common["cp"]), "pool completed-depth mismatch")
        delta = base["cp"] - common["cp"]
        require(delta >= -25 and proof.get("reference_delta_cp") == delta, "pool reference delta")
        require(isinstance(proof.get("naturalness"), dict) and proof["naturalness"].get("admitted") is True, "pool naturalness missing")
        matches = [probe for probe in original.get("probes", []) if isinstance(probe, dict) and probe.get("uci") == uci
                   and probe.get("admitted") is True and probe.get("error") is None
                   and probe.get("naturalness", {}).get("admitted") is True]
        matches = [probe for probe in matches if _line_equal(probe.get("candidate_compared", {}), common)
                   and _line_equal(probe.get("candidate_final", {}), final)]
        require(matches, "expanded candidate absent from admitted original native probes")
        for probe in matches:
            require(probe.get("compared_depth") == common["depth"], "original probe common depth")
            require(probe.get("naturalness") == proof["naturalness"], "native naturalness evidence changed")
            require(probe.get("reference_delta_cp") is None or probe["reference_delta_cp"] == delta, "original probe delta mismatch")
            require(probe.get("loss_cp") is None or probe["loss_cp"] == max(0, delta), "original probe loss mismatch")
            raw = probe.get("candidate_final_raw")
            if raw is not None:
                raw_native_final(raw, final)
        extras[uci] = {"common": common, "final": final, "individual": False}
    selected = referee.get("selected_uci")
    if selected in extras:
        proof = extras[selected]
        require(_line_equal(native_line(board, decision.get("candidate_compared"), selected, "selected own common"), proof["common"])
                and _line_equal(native_line(board, decision.get("candidate_final"), selected, "selected own final"), proof["final"]), "third choice top own score evidence differs")
        require(decision.get("selected_cp_own") == proof["common"]["cp"]
                and decision.get("selected_cp_white") == proof["common"]["cp_white"], "external score substituted for own score")
        require(decision.get("postmove_verification", {}).get("valid") is False
                and decision.get("band_control", {}).get("selected_postmove_cp") is None, "third choice falsely claims native child verification")
        if proof["individual"]:
            require(decision.get("native_comparison_available") is False and decision.get("loss_cp") is None
                    and decision.get("compared_depth") is None and decision.get("native_candidate_depth") == proof["common"]["depth"]
                    and decision.get("native_final_depth") == proof["final"]["depth"], "shallow scores relabeled as baseline comparison")
            require(decision.get("band_control", {}).get("selected_final_cp") == proof["final"]["cp"], "completed final native score lost")
    return {row["uci"] for row in pool}, selected in extras


def accepted_referee_proof(board, referee):
    """Check the score comparisons without importing the selector under audit."""
    require(referee.get("accepted") is True and referee.get("status") == "ready", "accepted referee state")
    rows = referee.get("candidates")
    require(isinstance(rows, list) and 2 <= len(rows) <= 4, "accepted candidate round size")
    sign = 1 if board.turn else -1
    require(len({row.get("uci") for row in rows}) == len(rows), "duplicate screened candidate")
    require({row.get("multipv") for row in rows} == set(range(1, len(rows) + 1)), "incomplete MultiPV ranks")
    for row in rows:
        require(row.get("depth") == referee.get("depth") and type(row.get("depth")) is int and row["depth"] >= 6
                and row.get("bound") == "exact", "screened depths/bounds differ")
        replay = _pv(board, row.get("pv_uci"), row.get("uci"), "Stockfish screened candidate")
        cp = row.get("cp_white", row.get("cp"))
        require(row.get("cp") == cp and (cp is None or type(cp) is int), "screened CP alias")
        require(row.get("mate_white") == row.get("mate")
                and (type(row.get("mate")) is int if cp is None else row.get("mate") is None and not replay.is_checkmate()), "screened score kind/alias")
        require(row.get("cp_own") == (cp * sign if cp is not None else None), "screened CP side")
    by_uci = {row["uci"]: row for row in rows}
    baseline, chosen = by_uci[referee["baseline_uci"]], by_uci[referee["selected_uci"]]
    require(type(baseline.get("cp_own")) is int and type(chosen.get("cp_own")) is int
            and chosen.get("mate") is None, "nonfinite accepted reference")
    band = referee.get("band")
    require(isinstance(band, dict), "accepted band absent")
    lower, upper, target = (band[key] for key in ("lower_cp_own", "upper_cp_own", "target_cp_own"))
    baseline_cp, chosen_cp = baseline["cp_own"], chosen["cp_own"]
    ramp = max(0, min(1, (len(board.move_stack) - 40) / 58))
    expected = (20 + ramp * (baseline_cp - 20), -80 + ramp * min(0, baseline_cp + 80), 80 + ramp * max(0, baseline_cp - 80))
    require(all(abs(a - b) < 1e-6 for a, b in zip((target, lower, upper), expected)), "band/ramp computation mismatch")
    floor = min(lower, baseline_cp)
    require(band.get("baseline_cp_own") == baseline_cp and abs(band.get("ramp") - ramp) < 1e-6, "baseline/ramp metadata")
    def distance(cp):
        excess = max(lower - cp, cp - upper, 0)
        return (abs(cp - target), excess) if ramp > 0 else (excess, abs(cp - target))
    child = board.copy(stack=True); child.push_uci(chosen["uci"])
    post = referee.get("postmove")
    require(isinstance(post, dict) and post.get("fen") == child.fen(en_passant="fen"), "missing/wrong child position")
    require(type(post.get("depth")) is int and post["depth"] >= 4 and post.get("bound") == "exact"
            and type(post.get("cp_white")) is int and post.get("mate") is None, "invalid child score")
    _pv(child, post.get("pv_uci"), post.get("uci"), "Stockfish unrestricted child")
    child_cp = post["cp_white"] * sign
    require(post.get("cp_own") == child_cp and abs(child_cp - chosen_cp) <= 80, "child POV/score-disagreement guard")
    require(post.get("disagreement_cp") == abs(child_cp - chosen_cp) and post.get("max_disagreement_cp") == 80, "child guard metadata")
    if referee["policy"] in POLICIES[1:]:
        require(abs(band.get("safety_floor_cp_own") - floor) < 1e-6, "declared safety floor")
        require(chosen_cp >= floor and child_cp >= floor and distance(child_cp) < distance(baseline_cp), "v2 child floor/progress failure")
        eligible = [row for row in rows if type(row.get("cp_own")) is int and row["cp_own"] >= floor]
        expected_choice = min(eligible, key=lambda row:(*distance(row["cp_own"]),row["uci"] != baseline["uci"],row["uci"]))
        require(chosen["uci"] == expected_choice["uci"], "v2 comparator/tie selection mismatch")
        partial = not (lower <= chosen_cp <= upper and lower <= child_cp <= upper)
        require((referee.get("reason") == "accepted_reference_partial_recovery") == partial, "partial recovery mislabeled as full-band acceptance")
    else:
        require(lower <= chosen_cp <= upper and lower <= child_cp <= upper, "v1 strict band failed")
    require(referee.get("cp_white") == chosen.get("cp_white") and referee.get("mate_white") is None, "selected external score alias mismatch")


def metrics(record, window):
    scores = {row["ply"]: row for row in record.get("judgements", [])}
    actual = [scores[ply] for ply in range(1, window + 1) if ply in scores]
    finite = [row for row in actual if finite_cp(row)]
    within = {limit: sum(abs(row["cp_white"]) <= limit for row in finite) for limit in (100, 200)}
    sign = 1 if record["sparring_color"] == "white" else -1
    exact_mate = [row for row in actual if row.get("status") == "exact" and type(row.get("mate_white")) is int]
    terminals = [row for row in actual if row.get("status") == "terminal_rules"]
    unknown = [row for row in actual if not finite_cp(row) and row not in exact_mate and row not in terminals]
    first_exits, changes = {}, []
    for ply in range(1, min(record["plies"], window) + 1):
        current, previous = scores.get(ply, {}), scores.get(ply - 1, {})
        move = record["moves"][ply - 1]
        for threshold in (100, 200):
            if threshold not in first_exits and (finite_cp(current) and abs(current["cp_white"]) > threshold
                    or current.get("status") == "exact" and type(current.get("mate_white")) is int
                    or current.get("status") == "terminal_rules" and current.get("termination") == "checkmate"):
                cp = current.get("cp_white")
                first_exits[threshold] = {"ply": ply, "actor": move["actor"], "uci": move["uci"],
                                         "cp_white": cp, "mate_white": current.get("mate_white"),
                                         "own_direction": "ahead" if type(cp) is int and cp * sign > 0 else
                                                          "behind" if type(cp) is int else "decisive_or_terminal"}
        if finite_cp(current) and finite_cp(previous):
            now, old = current["cp_white"], previous["cp_white"]
            excess = max(abs(now) - 100, 0) - max(abs(old) - 100, 0)
            changes.append({"ply": ply, "actor": move["actor"], "excess_increase_cp": excess,
                            "imbalance_increase_200": excess >= 200, "raw_cp_loss_own": (old - now) * sign})
    # Keep excursions distinct, including returns produced by the opponent.
    excursions, pending = [], None
    for ply in range(1, record["plies"] + 1):
        value = scores.get(ply, {})
        if pending is not None:
            pending["own_moves_after_start"] += int(record["moves"][ply - 1]["actor"] == "regicide")
        if not finite_cp(value):
            if pending is not None and pending["own_moves_after_start"] <= 2:
                pending["unscored_horizon_positions"].append(ply)
            continue
        cp = value["cp_white"]
        if pending is None and ply <= window and abs(cp) > 200:
            pending = {"start_ply": ply, "start_actor": record["moves"][ply - 1]["actor"],
                       "start_cp_white": cp, "own_moves_after_start": 0, "unscored_horizon_positions": []}
        elif pending is not None:
            if abs(cp) <= 100:
                outcome = (True if pending["own_moves_after_start"] <= 2 else
                           None if pending["unscored_horizon_positions"] else False)
                pending.update(return_ply=ply, return_actor=record["moves"][ply - 1]["actor"],
                               returned_within_two_own_moves=outcome, censored=outcome is None)
                excursions.append(pending); pending = None
    if pending is not None:
        known_failure = pending["own_moves_after_start"] >= 2 and not pending["unscored_horizon_positions"]
        pending.update(return_ply=None, returned_within_two_own_moves=False if known_failure else None,
                       censored=not known_failure)
        excursions.append(pending)
    own_rows = [row for row in record["moves"] if row["actor"] == "regicide" and not row.get("forced_opening")]
    elapsed = [row["elapsed_ms"] for row in own_rows]
    receipts = [row.get("decision", {}).get("referee") for row in own_rows if isinstance(row.get("decision"), dict)]
    receipts = [row for row in receipts if isinstance(row, dict)]
    forced_count = min(len(record.get("opening_uci", [])), window)
    unforced = [row for row in actual if not record["moves"][row["ply"] - 1].get("forced_opening")]
    unforced_finite = [row for row in unforced if finite_cp(row)]
    unforced100 = sum(abs(row["cp_white"]) <= 100 for row in unforced_finite)
    unforced200 = sum(abs(row["cp_white"]) <= 200 for row in unforced_finite)
    planned_unforced = window - forced_count
    extra_choices = []
    for row in own_rows:
        decision = row.get("decision") or {}; receipt = decision.get("referee") or {}; proposal = decision.get("regicide_proposal") or {}
        if receipt.get("applied") is True and row["uci"] not in (proposal.get("baseline_uci"), proposal.get("selected_uci")):
            selected_pool = next((candidate for candidate in receipt.get("native_pool", []) if candidate.get("uci") == row["uci"]), {})
            extra_choices.append({"ply": row["ply"], "uci": row["uci"], "native_cp_own": decision.get("selected_cp_own"),
                                  "reference_cp_white": receipt.get("cp_white"), "reason": receipt.get("reason"),
                                  "origin": selected_pool.get("origin"), "native_comparison_available": decision.get("native_comparison_available"),
                                  "native_candidate_depth": decision.get("native_candidate_depth"), "native_final_depth": decision.get("native_final_depth"),
                                  "native_child_claim": decision.get("postmove_verification", {}).get("valid")})
    return {"window_plies": window, "observed": len(actual), "finite": len(finite),
            "mate": len(exact_mate), "rule_terminal": len(terminals), "unknown_observed": len(unknown),
            "not_reached": window - len(actual), "within100": within[100], "within200": within[200],
            "density100_finite": within[100] / len(finite) if finite else None,
            "density200_finite": within[200] / len(finite) if finite else None,
            "conservative100_of40": within[100] / window, "conservative200_of40": within[200] / window,
            "strict_all40_within100": len(finite) == window and within[100] == window,
            "reached40": record["plies"] >= window, "first_exit100": first_exits.get(100),
            "first_exit200": first_exits.get(200), "own_below_minus200": sum(row["cp_white"] * sign < -200 for row in finite),
            "own_above_plus200": sum(row["cp_white"] * sign > 200 for row in finite),
            "imbalance_increase200_count": sum(row["imbalance_increase_200"] for row in changes),
            "changes": changes, "excursions": excursions, "errors": len(record.get("errors", [])),
            "early_legal_terminal": bool(record.get("legal_result") and record["plies"] < window),
            "capped": bool(record.get("capped")), "termination": record["termination"],
            "own_wall_ms": {"n": len(elapsed), "mean": statistics.mean(elapsed) if elapsed else None,
                             "median": statistics.median(elapsed) if elapsed else None,
                             "p95": percentile(elapsed, .95), "max": max(elapsed) if elapsed else None},
            "referee_receipts": len(receipts), "referee_statuses": dict(Counter(row.get("status") for row in receipts)),
            "referee_reasons": dict(Counter(row.get("reason") for row in receipts)),
            "referee_applied": sum(row.get("applied") is True for row in receipts),
            "referee_selected_proposals": sum(row.get("applied") is True and row.get("selected_uci") != row.get("baseline_uci") for row in receipts),
            "partial_recovery_acceptances": sum(row.get("accepted") is True and row.get("reason") == "accepted_reference_partial_recovery" for row in receipts),
            "expanded_native_pool_selections": extra_choices,
            "native_pool_origin_counts": dict(Counter(candidate.get("origin") for receipt in receipts for candidate in receipt.get("native_pool", []))),
            "native_discovery_reasons": dict(Counter((receipt.get("native_discovery") or {}).get("reason") for receipt in receipts if receipt.get("native_discovery") is not None)),
            "selection_scope": "Stockfish selects among a bounded set of native Regicide candidates; not standalone native move selection" if receipts else "standalone Regicide sparring",
            "unforced_window": {"forced_prefix_positions": forced_count, "planned_positions": planned_unforced,
                "observed_positions": len(unforced), "finite": len(unforced_finite),
                "unscored_observed": len(unforced) - len(unforced_finite), "missing_or_not_reached": planned_unforced - len(unforced),
                "within100": unforced100, "within200": unforced200,
                "density100_finite": unforced100 / len(unforced_finite) if unforced_finite else None,
                "density200_finite": unforced200 / len(unforced_finite) if unforced_finite else None,
                "conservative100_of_planned": unforced100 / planned_unforced if planned_unforced else None,
                "conservative200_of_planned": unforced200 / planned_unforced if planned_unforced else None,
                "strict_all_unforced_within100": len(unforced_finite) == planned_unforced and unforced100 == planned_unforced}}


def inspect_game(folder, record, config, entry):
    require(record["initial_fen"] == chess.STARTING_FEN, "nonstandard recorded root")
    board, fens, ucis = chess.Board(), {0: chess.STARTING_FEN}, []
    for ply, row in enumerate(record["moves"], 1):
        own = (board.turn == chess.WHITE) == (record["sparring_color"] == "white")
        actor = "regicide" if own else "opponent"
        require(row["ply"] == ply and row["actor"] == actor, "move actor/ply mismatch")
        require(row["before_fen"] == board.fen(en_passant="fen"), "before FEN mismatch")
        move = chess.Move.from_uci(row["uci"])
        require(move in board.legal_moves and row["san"] == board.san(move), "illegal move or SAN mismatch")
        require(row["forced_opening"] == (ply <= len(entry["opening_uci"])), "forced opening flag mismatch")
        if row["forced_opening"]:
            require(row["uci"] == entry["opening_uci"][ply - 1], "forced opening history mismatch")
        elif own:
            decision = row.get("decision")
            require(isinstance(decision, dict), "own decision absent")
            require(decision.get("history_uci") == ucis and decision.get("before_fen") == row["before_fen"]
                    and decision.get("selected_uci") == row["uci"], "own decision does not match actual history")
            referee = decision.get("referee")
            if isinstance(referee, dict):
                require(referee.get("selected_uci") == row["uci"], "referee final move differs from actual move")
                allowed = {decision.get("regicide_proposal", {}).get(key) for key in ("baseline_uci", "selected_uci")}
                host_policy = record["host_configuration"]["referee"].get("policy")
                if host_policy in POLICIES[1:] and "native_pool" in referee:
                    proof_receipt = dict(referee)
                    proof_receipt.setdefault("policy", host_policy)
                    allowed, _expanded = native_pool(board, decision, proof_receipt)
                if referee.get("applied"):
                    proposal = decision.get("regicide_proposal", {})
                    require(referee.get("source") == SOURCE and referee.get("policy") in POLICIES
                            and referee.get("policy") == record["host_configuration"]["referee"].get("policy"), "referee provenance mismatch")
                    require(referee.get("binary_sha256") == record["host_configuration"]["referee"].get("binary_sha256"), "referee binary identity mismatch")
                    require(referee.get("fen") == row["before_fen"] and referee.get("identity_verified") is True,
                            "applied referee context mismatch")
                    require(row["uci"] in allowed, "foreign move selected by referee")
                    require(row["uci"] == proposal.get("baseline_uci") or referee.get("accepted") is True, "rejected concession applied")
                    if referee.get("accepted") is True:
                        accepted_referee_proof(board, referee)
        board.push(move); ucis.append(move.uci()); fens[ply] = board.fen(en_passant="fen")
        require(row["after_fen"] == fens[ply], "after FEN mismatch")
    require(record["uci_moves"] == ucis and record["plies"] == len(ucis), "record history mismatch")
    require(record["final_fen"] == fens[len(ucis)], "final FEN mismatch")
    pgn_path = folder / f"game-{record['game']:03d}.pgn"
    stream = io.StringIO(pgn_path.read_text(encoding="utf-8"))
    pgn = chess.pgn.read_game(stream)
    require(pgn is not None and not pgn.errors and chess.pgn.read_game(stream) is None, "invalid multi-game PGN")
    require([move.uci() for move in pgn.mainline_moves()] == ucis and pgn.headers["Result"] == record["result"], "PGN mismatch")
    jsonl_path = folder / f"game-{record['game']:03d}.moves.jsonl"
    rows = [json.loads(line) for line in jsonl_path.read_text(encoding="utf-8").splitlines() if line]
    require(rows == record["moves"], "JSONL and final record disagree")
    if record.get("legal_result"):
        outcome = board.outcome(claim_draw=True)
        require(outcome is not None and outcome.result() == record["result"], "unproved legal result")
    else:
        require(record["result"] == "*", "capped/error game counted as a result")
    if record.get("capped"):
        require(len(ucis) >= config["max_plies"] and not board.is_game_over(claim_draw=True), "invalid cap")
    metadata = record.get("host_configuration", {}).get("referee", {})
    if config["referee"] == "on":
        require(metadata.get("configured") is True and metadata.get("assisted") is True, "assisted arm not configured")
    else:
        require(not metadata.get("configured") and not metadata.get("assisted"), "baseline unexpectedly assisted")
    for process in record.get("processes", []) + record.get("judge_processes", []):
        require(process.get("closed") is True and process.get("exited") is True, "playing process not confirmed closed")
    judged = record.get("judgements", [])
    if judged:
        require([row["ply"] for row in judged] == list(range(len(ucis) + 1)), "judge positions incomplete/duplicated")
        for row in judged:
            require(row["fen"] == fens[row["ply"]], "judge attached to wrong position")
            if row["status"] == "exact":
                require(row.get("bound") == "exact", "bounded judge score accepted")
                require((type(row.get("cp_white")) is int) != (type(row.get("mate_white")) is int), "invalid score kind")
                require(type(row.get("depth")) is int and row["depth"] >= (1 if config.get("judge_nodes") else config["judge_depth"]), "judge depth incomplete")
                replay = chess.Board(row["fen"])
                require(isinstance(row.get("pv_uci"), list) and row["pv_uci"], "judge PV missing")
                for uci in row["pv_uci"]:
                    move = chess.Move.from_uci(uci); require(move in replay.legal_moves, "illegal judge PV"); replay.push(move)
            elif row["status"] == "terminal_rules":
                current = chess.Board()
                for uci in ucis[:row["ply"]]:
                    current.push_uci(uci)
                require(current.outcome(claim_draw=True) is not None, "invalid terminal-rule judgement")
    calculated = metrics(record, config["close_plies"]) if judged else None
    if calculated is not None:
        recorded = record.get("close_metrics", {})
        for key, alias in (("within100", "within_100"), ("within200", "within_200"), ("finite", "exact_finite"),
                           ("strict_all40_within100", "strict_all_window_within_100"), ("reached40", "reached_window")):
            require(calculated[key] == recorded.get(alias), "driver metric mismatch: " + key)
    return {"game": record["game"], "pair_key": record["pair_key"], "color": record["sparring_color"],
            "opponent_elo": record["opponent_elo"], "plies": len(ucis), "metrics": calculated,
            "playing_started_at": record["started_at"], "playing_finished_at": record["finished_at"],
            "files": {path.name: digest(path) for path in (pgn_path, jsonl_path, folder / f"game-{record['game']:03d}.json")}}


def audit_run(folder):
    folder = Path(folder).resolve(); manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    config = manifest["config"]
    require(manifest["pipeline"] == "regicide.sparring-close-paired.v1", "unknown pipeline")
    findings = []
    require(manifest["driver_sha256_before"] == EXPECTED_DRIVER_SHA, "unexpected frozen driver")
    for key in ("driver_sha256_after_play", "driver_sha256_after"):
        if key in manifest:
            require(manifest[key] == manifest["driver_sha256_before"], "driver changed")
    for key in ("source_sha256_after_play", "source_sha256_after"):
        if key in manifest:
            require(manifest[key] == manifest["source_sha256_before"], "recorded source changed")
    if "binary_sha256_after" in manifest:
        require(manifest["binary_sha256_after"] == manifest["binary_sha256_before"], "recorded binary changed")
    root = Path(config["source_root"])
    current_commit = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True, check=True, timeout=10).stdout.strip()
    current_dirty = subprocess.run(["git", "-C", str(root), "status", "--porcelain", "--untracked-files=normal"], capture_output=True, text=True, check=True, timeout=10).stdout.strip()
    require(manifest["source"].get("dirty") is False and current_commit == manifest["source"].get("commit") and not current_dirty, "source worktree not clean/frozen at recorded commit")
    for relative, expected in manifest["source_sha256_before"].items():
        require(digest(root / relative) == expected, "frozen source changed: " + relative)
    for name, expected in manifest["binary_sha256_before"].items():
        require(digest(config[name]) == expected, "binary changed: " + name)
    records = []
    for entry in manifest["schedule"]:
        path = folder / f"game-{entry['game']:03d}.json"
        if not path.is_file():
            raise ValueError("scheduled game not written: " + str(entry["game"]))
        record = json.loads(path.read_text(encoding="utf-8"))
        for key in ("game", "pair_key", "sparring_seed", "opponent_elo", "sparring_color", "opening_uci"):
            require(record[key] == entry[key], "schedule/record identity mismatch: " + key)
        if config["referee"] == "on":
            require(record.get("host_configuration", {}).get("referee", {}).get("binary_sha256") == manifest["binary_sha256_before"]["referee_binary"], "configured referee hash mismatch")
        records.append(inspect_game(folder, record, config, entry))
    complete = [row["metrics"] for row in records if row["metrics"] is not None]
    game_mean = {}
    for key in ("density100_finite", "density200_finite", "conservative100_of40", "conservative200_of40"):
        available = [row[key] for row in complete if row[key] is not None]
        game_mean[key] = statistics.mean(available) if available else None
    for key in ("density100_finite", "density200_finite", "conservative100_of_planned", "conservative200_of_planned"):
        available = [row["unforced_window"][key] for row in complete if row["unforced_window"][key] is not None]
        game_mean["unforced_" + key] = statistics.mean(available) if available else None
    return {"folder": str(folder), "variant": config["variant"], "referee": config["referee"], "source": manifest["source"],
            "status": manifest["status"], "config": config, "playing_started": manifest["started_at"],
            "playing_finished": manifest.get("play_finished_at") or max((row["playing_finished_at"] for row in records), default=None),
            "finished_at": manifest.get("finished_at"),
            "games": records, "game_weighted_means": game_mean, "findings": findings,
            "scope": "matched practical 10+5 segments; CPU cost differs; same Stockfish family reanalysis is not an independent engine oracle"}


def runner_phases(path, runs):
    """Use launch/exit evidence; a barrier wait is not a judging interval."""
    path = Path(path).resolve()
    runner = json.loads(path.read_text(encoding="utf-8"))
    require(runner.get("schema") == "regicide.experiment-batch.v1"
            and runner.get("status") == "completed" and not runner.get("failed_or_not_started_jobs"), "incomplete runner")
    phases = defaultdict(list)
    for job in runner["jobs"]:
        require(job.get("status") == "completed" and job.get("exit_code") == 0, "failed runner job")
        phases[job["phase"]].append(job)
    require(set(phases) == {1, 2}, "expected play then judge phases")
    last_play = max(job["finished_at"] for job in phases[1])
    first_judge = min(job["started_at"] for job in phases[2])
    require(datetime.fromisoformat(last_play) <= datetime.fromisoformat(first_judge), "play/judge phase overlap")
    events = []
    for job in runner["jobs"]:
        events.extend([(job["started_at"], 1), (job["finished_at"], -1)])
    active = peak = 0
    for _, delta in sorted(events, key=lambda row: (row[0], row[1])):
        active += delta; peak = max(peak, active)
    require(peak <= runner["workers"], "runner concurrency exceeds limit")
    for run in runs:
        matched = {}
        for phase in (1, 2):
            jobs = []
            for job in phases[phase]:
                argv = job["argv"]
                require("--stage" in argv and argv[argv.index("--stage") + 1] == ("play" if phase == 1 else "judge"), "runner stage mismatch")
                if "--output" in argv and Path(argv[argv.index("--output") + 1]).resolve() == Path(run["folder"]):
                    jobs.append(job)
            require(len(jobs) == 1, "runner does not uniquely cover audited folder")
            matched[phase] = jobs[0]
        for game in run["games"]:
            require(datetime.fromisoformat(matched[1]["started_at"]) <= datetime.fromisoformat(game["playing_started_at"])
                    <= datetime.fromisoformat(game["playing_finished_at"]) <= datetime.fromisoformat(matched[1]["finished_at"]), "game outside play job")
        run["offline_phase_started_at"] = matched[2]["started_at"]
        run["offline_phase_finished_at"] = matched[2]["finished_at"]
    return {"file": str(path), "sha256": digest(path), "play_jobs": len(phases[1]), "judge_jobs": len(phases[2]),
            "last_play_job_finished_at": last_play, "first_judge_job_started_at": first_judge,
            "barrier_gap_seconds": (datetime.fromisoformat(first_judge) - datetime.fromisoformat(last_play)).total_seconds(),
            "peak_concurrent_jobs": peak, "workers": runner["workers"], "scope": "recorded process launch/exit times, not CPU isolation"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", type=Path, nargs="+"); parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runner", type=Path, help="two-phase batch result; prevents treating barrier waiting as judging")
    parser.add_argument("--expected-arms", nargs="+", help="require these unique arms in every matched case")
    parser.add_argument("--expected-pairs", type=int, help="require this many matched cases, each including all arms")
    args = parser.parse_args(argv)
    runs, failures = [], []
    for folder in args.runs:
        try:
            runs.append(audit_run(folder))
        except Exception as error:
            failures.append({"folder": str(folder), "type": type(error).__name__, "message": str(error)})
    phase_evidence = None
    if args.runner:
        try:
            phase_evidence = runner_phases(args.runner, runs)
        except Exception as error:
            failures.append({"folder": str(args.runner), "type": type(error).__name__, "message": str(error)})
    pairs = defaultdict(list)
    for run in runs:
        for game in run["games"]:
            pairs[(game["pair_key"], game["color"])].append((run["variant"], game))
    comparisons = []
    for (pair_key, color), values in pairs.items():
        if len(values) < 2:
            continue
        if len({name for name, game in values}) != len(values):
            failures.append({"pair_key": pair_key, "message": "duplicate arm in matched case"})
        comparisons.append({"pair_key": pair_key, "color": color, "arms": {name: game["metrics"] for name, game in values}})
    if args.expected_arms:
        for (pair_key, color), values in pairs.items():
            if sorted(name for name, game in values) != sorted(args.expected_arms):
                failures.append({"pair_key": pair_key, "message": "matched case missing/extra arm"})
        if set(run["variant"] for run in runs) != set(args.expected_arms):
            failures.append({"message": "audited arm set differs from plan"})
    if args.expected_pairs is not None and (len(pairs) != args.expected_pairs or len(comparisons) != args.expected_pairs):
        failures.append({"message": "matched-case count differs from plan"})
    conditions = defaultdict(list)
    for run in runs:
        for game in run["games"]:
            conditions[(game["pair_key"], game["color"])].append(run["config"])
    for (pair_key, color), configs in conditions.items():
        ignored = {"variant", "referee", "source_root", "output"}
        normalized = [{key: value for key, value in config.items() if key not in ignored} for config in configs]
        if any(value != normalized[0] for value in normalized[1:]):
            failures.append({"pair_key": pair_key, "message": "matched-case conditions differ"})
    arm_metrics = defaultdict(list)
    for run in runs:
        arm_metrics[run["variant"]].extend(game["metrics"] for game in run["games"] if game["metrics"] is not None)
    aggregate = {}
    for arm, values in arm_metrics.items():
        aggregate[arm] = {"games": len(values), "window_positions": sum(row["window_plies"] for row in values),
            **{key: sum(row[key] for row in values) for key in ("within100", "within200", "finite", "unknown_observed", "mate", "rule_terminal", "not_reached", "strict_all40_within100")},
            "game_weighted_density100": statistics.mean(row["conservative100_of40"] for row in values),
            "game_weighted_density200": statistics.mean(row["conservative200_of40"] for row in values),
            "unforced": {"planned_positions": sum(row["unforced_window"]["planned_positions"] for row in values),
                **{key: sum(row["unforced_window"][key] for row in values) for key in ("within100", "within200", "finite", "unscored_observed", "missing_or_not_reached")},
                "game_weighted_density100": statistics.mean(row["unforced_window"]["conservative100_of_planned"] for row in values),
                "game_weighted_density200": statistics.mean(row["unforced_window"]["conservative200_of_planned"] for row in values)}}
    overlaps = []
    for first in runs:
        for second in runs:
            if first is second or not first["playing_finished"] or not first["finished_at"]:
                continue
            start = datetime.fromisoformat(first.get("offline_phase_started_at", first["playing_finished"]))
            end = datetime.fromisoformat(first.get("offline_phase_finished_at", first["finished_at"]))
            for game in second["games"]:
                play_start, play_end = (datetime.fromisoformat(game[key]) for key in ("playing_started_at", "playing_finished_at"))
                overlap = max(0, (min(end, play_end) - max(start, play_start)).total_seconds())
                if overlap:
                    overlaps.append({"post_play_arm": first["variant"], "playing_arm": second["variant"],
                                     "game": game["game"], "post_play_phase_overlap_seconds": overlap,
                                     "scope": "judge job launch/exit interval" if phase_evidence else "post-play phase includes judging, barrier waiting and bookkeeping; not a CPU-time measurement"})
    output = {"schema": SCHEMA, "created_at": datetime.now(timezone.utc).isoformat(), "audit_source_sha256": digest(__file__),
              "passed": not failures, "failures": failures, "runs": runs, "paired_comparisons": comparisons,
              "arm_aggregates": aggregate,
              "phase_evidence": phase_evidence,
              "cross_run_phase_overlaps": overlaps,
              "methodological_status": "development_pilot_with_cross_phase_overlap" if overlaps else "no_cross_phase_overlap_observed",
              "limitations": ["One or few games cannot establish causal improvement or Elo.",
                              "Limited Stockfish has uncontrolled random selection; paired settings do not force identical trajectories.",
                              "Pilot stage=all can overlap one arm's offline judging with the other arm's play; use stage=play barrier for validation."]}
    args.output.write_text(json.dumps(output, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
    print(json.dumps({"passed": output["passed"], "runs": len(runs), "failures": failures, "output": str(args.output)}, ensure_ascii=False))
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
