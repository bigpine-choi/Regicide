"""Read-only execution audit; writes only this ignored audit JSON."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def moment(value):
    return datetime.fromisoformat(value).timestamp()


def overlap(a, b):
    return max(0.0, min(a[1], b[1]) - max(a[0], b[0]))


def concurrency(jobs):
    events = sorted([(moment(row["started_at"]), 1) for row in jobs]
                    + [(moment(row["finished_at"]), -1) for row in jobs], key=lambda row: (row[0], row[1]))
    active, maximum, spans = 0, 0, Counter()
    previous = events[0][0]
    for at, difference in events:
        spans[active] += at - previous
        active += difference
        maximum = max(maximum, active)
        previous = at
    return {"maximum": maximum, "seconds_at_concurrency": dict(sorted(spans.items()))}


def sampled_load(samples, windows):
    weighted, seconds = 0.0, 0.0
    maxima, memory = [], []
    for index, row in enumerate(samples):
        at = moment(row["at"])
        if any(start <= at <= end for start, end in windows) and row.get("memory_percent") is not None:
            memory.append(row["memory_percent"])
        if index and row.get("cpu_percent") is not None:
            interval = moment(samples[index - 1]["at"]), at
            duration = sum(overlap(interval, window) for window in windows)
            if duration:
                weighted += row["cpu_percent"] * duration
                seconds += duration
                maxima.append(row["cpu_percent"])
    return {"cpu_interval_overlap_seconds": seconds, "weighted_desktop_cpu_percent": weighted / seconds if seconds else None,
            "max_overlapping_five_second_cpu_percent": max(maxima) if maxima else None,
            "memory_sample_min_percent": min(memory) if memory else None,
            "memory_sample_max_percent": max(memory) if memory else None,
            "interpretation": "temporal exposure to total desktop load; not this arm's process CPU; interval-boundary prorating assumes uniform load"}


def main():
    runner_path = ROOT / "primary-runner/result.json"
    samples_path = ROOT / "primary-runner/system-samples.jsonl"
    runner = load(runner_path)
    samples = [json.loads(line) for line in samples_path.read_text(encoding="utf-8").splitlines()]
    inputs = [runner_path, samples_path, ROOT / "primary-play.json", ROOT / "primary-judge.json"]
    playing, judging = ([row for row in runner["jobs"] if row["phase"] == phase] for phase in (1, 2))
    play_end = max(moment(row["finished_at"]) for row in playing)
    judge_start = min(moment(row["started_at"]) for row in judging)
    groups = {name: [row for row in playing if f"-{name}-" in row["label"]] for name in ("before", "v1")}
    report = {"scope": "execution fairness only; no strength inference or process-specific CPU attribution",
              "runner_status": runner["status"], "jobs_total": len(runner["jobs"]),
              "playing_jobs": len(playing), "judging_jobs": len(judging),
              "all_job_exit_zero": all(row.get("exit_code") == 0 for row in runner["jobs"]),
              "global_barrier": {"passed": judge_start >= play_end, "recorded_gap_seconds": judge_start - play_end,
                                 "last_play_end_utc": max(row["finished_at"] for row in playing),
                                 "first_judge_start_utc": min(row["started_at"] for row in judging)},
              "concurrency_all": concurrency(runner["jobs"]), "concurrency_play": concurrency(playing),
              "concurrency_judge": concurrency(judging), "actual_start_order": [row["label"] for row in sorted(playing, key=lambda row: row["started_at"])],
              "system_sampling": {"samples": len(samples), "valid_cpu": sum(row.get("cpu_percent") is not None for row in samples),
                                  "status_counts": dict(Counter(row.get("status") for row in samples)),
                                  "max_sample_gap_seconds": max(moment(b["at"]) - moment(a["at"]) for a, b in zip(samples, samples[1:])),
                                  "unobserved_tail_seconds": moment(runner["finished_at"]) - moment(samples[-1]["at"]),
                                  "raw_runner_summary": runner["system_load"]},
              "temporal_load_by_arm": {name: sampled_load(samples, [(moment(row["started_at"]), moment(row["finished_at"])) for row in rows])
                                       for name, rows in groups.items()},
              "temporal_load_by_phase": {str(phase): sampled_load(samples, [(min(moment(row["started_at"]) for row in rows),
                                                        max(moment(row["finished_at"]) for row in rows))])
                                         for phase, rows in ((1, playing), (2, judging))},
              "cases": [], "process_instances_by_arm": {}, "all_recorded_engine_processes_exited": True}
    roles = {name: Counter() for name in groups}
    cases = {}
    engine_total = 0
    option_sets = {}
    for path in sorted((ROOT / "primary").glob("*/manifest.json")):
        inputs.append(path)
        manifest = load(path)
        config = manifest["config"]
        arm = config["variant"]
        entry = manifest["schedule"][0]
        record_path = path.parent / f"game-{entry['game']:03d}.json"
        inputs.append(record_path)
        record = load(record_path)
        process_rows = [*record.get("processes", []), *record.get("judge_processes", [])]
        engine_total += len(process_rows)
        for row in process_rows:
            roles[arm][row["role"]] += 1
            option_sets.setdefault(row["role"], set()).add(json.dumps(row.get("options"), sort_keys=True))
            if row.get("exited") is not True:
                report["all_recorded_engine_processes_exited"] = False
        check = {"case": entry["game"], "arm": arm, "opponent_elo": entry["opponent_elo"],
                 "sparring_color": entry["sparring_color"], "sparring_seed": entry["sparring_seed"],
                 "pair_key": entry["pair_key"], "opening_uci": entry["opening_uci"],
                 "source_commit": manifest["source"].get("commit"), "source_dirty": manifest["source"].get("dirty"),
                 "sources_before_after_equal": manifest["source_sha256_before"] == manifest["source_sha256_after"],
                 "binaries_before_after_equal": manifest["binary_sha256_before"] == manifest["binary_sha256_after"],
                 "driver_before_after_equal": manifest["driver_sha256_before"] == manifest["driver_sha256_after"],
                 "binary_hashes": manifest["binary_sha256_before"],
                 "conditions": {key: config.get(key) for key in ("time_control", "own_ms", "opponent_ms", "max_plies", "close_plies", "judge_depth", "judge_nodes", "move_timeout")}}
        cases.setdefault(entry["game"], {})[arm] = check
    for number, pair in sorted(cases.items()):
        before, current = pair["before"], pair["v1"]
        comparable = ("opponent_elo", "sparring_color", "sparring_seed", "pair_key", "opening_uci", "binary_hashes", "conditions")
        job_before = next(row for row in playing if row["label"].endswith(f"before-case-{number}"))
        job_current = next(row for row in playing if row["label"].endswith(f"v1-case-{number}"))
        windows = [(moment(row["started_at"]), moment(row["finished_at"])) for row in (job_before, job_current)]
        report["cases"].append({"case": number, "matched_conditions": all(before[key] == current[key] for key in comparable),
                                "arms": pair, "first_started": "before" if windows[0][0] < windows[1][0] else "v1",
                                "same_case_overlap_seconds": overlap(*windows),
                                "controller_job_wall_seconds": {"before": windows[0][1] - windows[0][0], "v1": windows[1][1] - windows[1][0]}})
    report["process_instances_by_arm"] = {name: dict(values) for name, values in roles.items()}
    report["recorded_engine_process_instances"] = engine_total
    report["recorded_engine_options_by_role"] = {name: [json.loads(value) for value in sorted(values)] for name, values in option_sets.items()}
    report["matched_case_pairs"] = len(cases)
    report["rating_coverage"] = sorted({row["arms"]["before"]["opponent_elo"] for row in report["cases"]})
    report["limitations"] = [
        "Recorded job timestamps bound Python child lifetimes, not individual engine-search intervals.",
        "The worker pool maintains a global phase barrier, not a per-case barrier; different case IDs can overlap.",
        "Extra candidate-referee work is intentional in v1; equal CPU budgets between arms are not claimed.",
        "System CPU covers the whole shared desktop. No per-process CPU counters or unrelated-process inventory were sampled.",
        "CPU values average each approximately five-second interval; shorter peaks and final trailing time are not isolated.",
        "The limited-strength opponent has no exposed RNG seed; matching its settings and Regicide seed does not fix its random draws.",
        "This primary batch covers only Elo 1320/1700, one start position and one before/v1 observation per color-condition case."
    ]
    report["input_sha256"] = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
    (ROOT / "primary-fairness-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("global_barrier", "concurrency_play", "concurrency_judge", "temporal_load_by_arm", "temporal_load_by_phase", "process_instances_by_arm", "recorded_engine_process_instances", "all_recorded_engine_processes_exited", "rating_coverage")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
