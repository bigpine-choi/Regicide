"""Package only allowlisted, completed Regicide sparring experiment evidence.

The dry run never creates the destination or a ZIP. No engine is started, no
source worktree is traversed, and no real user-game directory is inspected.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile

SCHEMA = "regicide.sparring-close-raw-package.v1"
GROUPS = {
    "pilot-before": (["pilot-before"], "development pilot; excluded from effect claims"),
    "pilot-v1": (["pilot-v1"], "development pilot; excluded from effect claims"),
    "primary": ([f"primary/{arm}-case-{case}" for case in range(1, 5) for arm in ("before", "v1")],
                "small original before/v1 development comparison"),
    "candidate-dev": ([f"candidate-dev/v2-case-{case}" for case in range(1, 5)],
                      "failed v2 performance candidate; valid development data retained"),
    "holdout-final": ([f"holdout-final/{arm}-case-{case}" for case in range(1, 5) for arm in ("before", "v1", "v3")],
                      "held-out opening/seed segment comparison after candidate freeze"),
}
REQUIRED_ROOT = (
    "hardware.json", "candidate-validation-plan.json", "holdout-opening.json",
    "primary-play.json", "primary-judge.json", "candidate-dev-play.json", "candidate-dev-judge.json",
    "holdout-final-play.json", "holdout-final-judge.json",
    "primary-independent-audit.json", "primary-independent-summary.json", "primary-fairness-audit.json",
    "candidate-v2-independent-audit.json", "candidate-v2-independent-summary.json", "candidate-dev-fairness-audit.json",
    "holdout-final-independent-audit.json", "holdout-final-independent-summary.json", "holdout-final-fairness-audit.json",
    "v3-known-failure-reuse.json", "baseline-blunder-diagnosis.json",
    "audit_independent.py", "run_batch.py", "package_artifacts.py",
)
COMPACT = ("primary-independent-summary.json", "candidate-v2-independent-summary.json",
           "holdout-final-independent-summary.json")
OPTIONAL_PATTERNS = (
    "*-independent-audit*.json", "*-independent-summary.json", "*-fairness-audit.json",
    "*-diagnosis.json", "audit-v3-preparation.json", "primary-fairness-audit.py",
)
RUNNERS = ("primary-runner", "candidate-dev-runner", "holdout-final-runner")
COUNTERFACTUALS = ("counterfactual-v1-v2", "counterfactual-holdout")


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def load(path, failures, object_required=True):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if object_required and not isinstance(value, dict):
            raise ValueError("JSON object required")
        return value
    except (OSError, ValueError, TypeError) as error:
        failures.append(f"{path.name}: {type(error).__name__}: {error}")
        return {}


def origin_dates(value):
    return {key: item for key, item in value.items() if key in
            ("created_at", "started_at", "finished_at", "captured_at", "captured_at_utc", "play_finished_at")}


def collect(base):
    """Inventory fixed experiment folders; validate but do not write anything."""
    base = base.resolve(strict=True)
    repo = base.parents[1]
    failures, entries, names, runs = [], [], set(), []

    def add(path, category, arc=None, required=True):
        path = Path(path)
        if not path.is_file():
            if required:
                failures.append(f"Missing required file: {path}")
            return
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(base) and not resolved.is_relative_to(repo / "scripts") and not resolved.is_relative_to(repo / "docs" / "experiments"):
            failures.append(f"Path escaped an allowed evidence root: {path}")
            return
        if any(part.casefold() in {"_private", "sources", "__pycache__"} for part in resolved.parts):
            failures.append(f"Private/reference/cache path rejected: {path}")
            return
        if resolved.suffix.lower() not in {".json", ".jsonl", ".pgn", ".py", ".md"}:
            failures.append(f"Unsupported payload extension: {path}")
            return
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != parent.parent):
            failures.append(f"Linked payload path rejected: {path}")
            return
        arc = arc or path.relative_to(base).as_posix()
        parts = PurePosixPath(arc).parts
        if not parts or ".." in parts or PurePosixPath(arc).is_absolute() or ":" in arc or "\\" in arc:
            failures.append(f"Unsafe archive entry: {arc}")
            return
        if arc.casefold() in names:
            return
        names.add(arc.casefold())
        data = path.read_bytes()
        entries.append({"path": str(path), "archive_entry": arc, "category": category,
                        "bytes": len(data), "sha256": digest(data), "source_mtime_ns": path.stat().st_mtime_ns})

    for group, (folders, label) in GROUPS.items():
        for folder in folders:
            root = base / folder
            path = root / "manifest.json"
            add(path, "run_manifest")
            manifest = load(path, failures)
            schedule, recorded = manifest.get("schedule"), manifest.get("games")
            if not isinstance(schedule, list) or len(schedule) != 1 or not isinstance(schedule[0], dict):
                failures.append(f"{folder}: exactly one scheduled segment required")
                continue
            case = schedule[0].get("game")
            if type(case) is not int or not 1 <= case <= 4:
                failures.append(f"{folder}: invalid scheduled game identity")
                continue
            if manifest.get("status") != "completed" or manifest.get("errors") != []:
                failures.append(f"{folder}: run not completed with errors=[] ({manifest.get('status')})")
            for flag, before, after in (("sources_unchanged", "source_sha256_before", "source_sha256_after"),
                                        ("driver_unchanged", "driver_sha256_before", "driver_sha256_after"),
                                        ("binaries_unchanged", "binary_sha256_before", "binary_sha256_after")):
                if (manifest.get(flag) is not True or not manifest.get(before)
                        or manifest.get(before) != manifest.get(after)):
                    failures.append(f"{folder}: missing/mismatched {flag}")
            if (not isinstance(recorded, list) or len(recorded) != 1 or not isinstance(recorded[0], dict)
                    or recorded[0].get("game") != case or recorded[0].get("errors") != []):
                failures.append(f"{folder}: manifest segment record missing or has execution errors")
            game_path = root / f"game-{case:03d}.json"
            add(game_path, "segment_game")
            add(root / f"game-{case:03d}.moves.jsonl", "move_journal")
            add(root / f"game-{case:03d}.pgn", "segment_pgn")
            game = load(game_path, failures)
            if game.get("errors") != [] or game.get("game") != case or not game.get("finished_at"):
                failures.append(f"{folder}: segment unfinished, identity mismatch or execution errors")
            judgements = game.get("judgements")
            if (not isinstance(judgements, list) or len(judgements) != len(game.get("moves", [])) + 1
                    or [row.get("ply") for row in judgements if isinstance(row, dict)] != list(range(len(game.get("moves", [])) + 1))):
                failures.append(f"{folder}: offline judgement count does not cover every played move")
            if any(row.get("exited") is not True for row in [*game.get("processes", []), *game.get("judge_processes", [])] if isinstance(row, dict)):
                failures.append(f"{folder}: an owned engine process lacks exited=true")
            expected_game_files = {game_path.resolve()}
            if {p.resolve() for p in root.glob("game-*.json")} != expected_game_files:
                failures.append(f"{folder}: unexpected/missing top-level segment game JSON")
            hosts = sorted((root / "host").glob("*/*.json"))
            if not hosts:
                failures.append(f"{folder}: no isolated host JSON records")
            for host_path in hosts:
                add(host_path, "isolated_host_record")
            runs.append({"folder": folder, "group": group, "label": label, "game": case,
                         "variant": manifest.get("config", {}).get("variant"), "source": manifest.get("source"),
                         "dates": origin_dates(manifest), "status": manifest.get("status"),
                         "plies": game.get("plies"), "result": game.get("result"), "termination": game.get("termination"),
                         "summary": manifest.get("summary"), "host_json_records": len(hosts)})
    if len(runs) != 26:
        failures.append(f"Expected exactly 26 segment games; found {len(runs)}")

    root_json = {}
    for name in REQUIRED_ROOT:
        add(base / name, "helper" if name.endswith(".py") else "evidence")
        if name.endswith(".json"):
            root_json[name] = load(base / name, failures,
                object_required=not (name.endswith(("-play.json", "-judge.json")) or name == "holdout-opening.json"))
    for pattern in OPTIONAL_PATTERNS:
        for path in sorted(base.glob(pattern)):
            add(path, "evidence" if path.suffix == ".json" else "helper")
    for name in ("primary-independent-audit.json", "candidate-v2-independent-audit.json", "holdout-final-independent-audit.json"):
        audit = root_json.get(name, {})
        if audit.get("passed") is not True or audit.get("failures") != []:
            failures.append(f"{name}: independent integrity audit has not passed")

    for folder in RUNNERS:
        add(base / folder / "result.json", "batch_result")
        add(base / folder / "system-samples.jsonl", "shared_desktop_samples")
        result = load(base / folder / "result.json", failures)
        jobs = result.get("jobs", [])
        if (result.get("status") != "completed" or not isinstance(jobs, list) or not jobs
                or result.get("failed_or_not_started_jobs") != 0
                or any(job.get("exit_code") != 0 for job in jobs if isinstance(job, dict))):
            failures.append(f"{folder}: batch is not complete with all jobs exit=0")

    counter_summaries = {}
    for folder in COUNTERFACTUALS:
        add(base / folder / "audit.json", "counterfactual_audit")
        audit = load(base / folder / "audit.json", failures)
        if audit.get("status") not in ("completed", "completed_with_unknowns"):
            failures.append(f"{folder}: counterfactual audit has not finished")
        if audit.get("input_errors") != []:
            failures.append(f"{folder}: counterfactual audit input errors")
        for flag in ("inputs_unchanged", "script_unchanged", "binary_unchanged", "all_owned_processes_exited"):
            if audit.get(flag) is not True:
                failures.append(f"{folder}: {flag} is not true")
        cases = audit.get("cases", [])
        if not isinstance(cases, list) or any(case.get("status") == "pending" for case in cases if isinstance(case, dict)):
            failures.append(f"{folder}: pending/malformed cases")
        for case in cases if isinstance(cases, list) else []:
            if isinstance(case, dict) and type(case.get("case")) is int:
                add(base / folder / f"case-{case['case']:03d}.json", "counterfactual_case")
        counter_summaries[folder] = {"dates": origin_dates(audit), "status": audit.get("status"),
                                    "summary": audit.get("summary"), "scope": audit.get("scope")}

    for folder in ("candidate-v2-tests", "candidate-v3-tests"):
        for path in sorted((base / folder).glob("*.json")):
            add(path, "targeted_regression_evidence")
    add(repo / "scripts" / "compare_sparring_referee.py", "helper", "helpers/compare_sparring_referee.py")
    add(repo / "scripts" / "audit_sparring_counterfactual.py", "helper", "helpers/audit_sparring_counterfactual.py")
    add(repo / "docs" / "experiments" / "2026-11-03-sparring-close-plan.md", "validation_plan",
        "protocol/2026-11-03-sparring-close-plan.md")
    entries.sort(key=lambda row: row["archive_entry"])
    return {"base": str(base), "entries": entries, "runs": runs, "counterfactuals": counter_summaries,
            "compact_summaries": {name: {"sha256": digest((base / name).read_bytes()),
                                        "source_mtime_ns": (base / name).stat().st_mtime_ns,
                                        "origin_dates": origin_dates(root_json.get(name, {}))}
                                  for name in COMPACT if (base / name).is_file()},
            "failures": list(dict.fromkeys(failures)), "ready": not failures}


def package(base, dest, dry_run=False):
    plan = collect(Path(base))
    dest = Path(dest).resolve()
    if dest.is_relative_to(Path(plan["base"])):
        plan["failures"].append("Destination must be outside the experiment input tree")
        plan["ready"] = False
    preview = {"dry_run": dry_run, "ready": plan["ready"], "segment_games": len(plan["runs"]),
               "groups": dict(Counter(row["group"] for row in plan["runs"])), "payload_files": len(plan["entries"]),
               "uncompressed_bytes": sum(row["bytes"] for row in plan["entries"]),
               "destination": str(dest), "failures": plan["failures"]}
    if dry_run:
        print(json.dumps(preview, ensure_ascii=False, indent=2))
        return 0
    if not plan["ready"]:
        print(json.dumps(preview, ensure_ascii=False, indent=2))
        return 1
    targets = [dest / name for name in ("raw-records.zip", "raw-manifest.json", "evidence-summary.json", *COMPACT)]
    if any(path.exists() for path in targets):
        raise FileExistsError("A package output already exists; inspect it before choosing a fresh destination")
    dest.mkdir(parents=True, exist_ok=True)
    archive = dest / "raw-records.zip"
    temporary = None
    started = utc()
    try:
        with tempfile.NamedTemporaryFile(dir=dest, suffix=".zip.tmp", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
            for row in plan["entries"]:
                data = Path(row["path"]).read_bytes()
                if len(data) != row["bytes"] or digest(data) != row["sha256"]:
                    raise ValueError(f"Input changed while packaging: {row['archive_entry']}")
                zipped.writestr(row["archive_entry"], data)
        with zipfile.ZipFile(temporary) as zipped:
            if zipped.testzip() is not None or zipped.namelist() != [row["archive_entry"] for row in plan["entries"]]:
                raise ValueError("Archive CRC or entry-list verification failed")
            for row in plan["entries"]:
                data = zipped.read(row["archive_entry"])
                if len(data) != row["bytes"] or digest(data) != row["sha256"]:
                    raise ValueError(f"Archive SHA verification failed: {row['archive_entry']}")
                row["source_sha256_after"] = digest(Path(row["path"]).read_bytes())
                if row["source_sha256_after"] != row["sha256"]:
                    raise ValueError(f"Source changed during archive verification: {row['archive_entry']}")
            compact_bytes = {name: zipped.read(name) for name in COMPACT}
        archive_meta = {"filename": archive.name, "bytes": temporary.stat().st_size,
                        "sha256": digest(temporary.read_bytes()), "reopened_crc_and_sha_verified": True}
        summary = {"schema": SCHEMA, "created_at": utc(), "archive": archive_meta,
                   "segment_games": len(plan["runs"]), "groups": dict(Counter(row["group"] for row in plan["runs"])),
                   "runs": plan["runs"], "counterfactuals": plan["counterfactuals"],
                   "compact_summaries_copied_without_changes": plan["compact_summaries"],
                   "scope": "20-fullmove segment diagnostics; pilot/development/failed-v2/held-out evidence kept distinct; no Elo or independent Regicide strength claim",
                   "exclusions": "No engines, source worktrees, SQLite databases, _private files, real user-game directories, host PGNs or unrelated task artifacts"}
        summary_data = encoded(summary)
        manifest = {"schema": SCHEMA, "started_at": started, "finished_at": utc(), "status": "verified",
                    "base": plan["base"], "archive": archive_meta, "segment_games": len(plan["runs"]),
                    "entry_count": len(plan["entries"]), "entries": plan["entries"],
                    "all_sources_unchanged": True, "evidence_summary_sha256": digest(summary_data),
                    "compact_summaries": plan["compact_summaries"], "validation_failures": []}
        os.replace(temporary, archive)
        temporary = None
        for name, data in compact_bytes.items():
            (dest / name).write_bytes(data)
            if digest((dest / name).read_bytes()) != plan["compact_summaries"][name]["sha256"]:
                raise ValueError("Compact summary copy SHA mismatch")
        (dest / "evidence-summary.json").write_bytes(summary_data)
        (dest / "raw-manifest.json").write_bytes(encoded(manifest))
        print(json.dumps({"status": "verified", "archive": archive_meta,
                          "segment_games": len(plan["runs"]), "entries": len(plan["entries"])}, ensure_ascii=False))
        return 0
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True, help="build/sparring-close-experiment")
    parser.add_argument("--dest", type=Path, required=True, help="docs/matches/2026-11-03-sparring-referee-close")
    parser.add_argument("--dry-run", action="store_true", help="Validate/list the plan without writing; ready=false is expected while experiments are running")
    options = parser.parse_args(argv)
    return package(options.base, options.dest, options.dry_run)


if __name__ == "__main__":
    raise SystemExit(main())
