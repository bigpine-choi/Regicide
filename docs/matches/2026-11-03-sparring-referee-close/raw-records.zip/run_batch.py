"""Dispatch literal argv jobs with bounded concurrency and an optional phase barrier.

Use --jobs play.json --then-jobs judge.json to finish ALL playing jobs before
starting any offline judge. Failures remain in result.json. No shell is used.
Only subprocesses launched here (and their contained descendants) are closed.
"""

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def read_jobs(path, cwd, phase):
    source = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(source, list) or not source:
        raise ValueError("Jobs JSON must be a nonempty list")
    result, labels = [], set()
    for number, job in enumerate(source, 1):
        if not isinstance(job, dict) or set(job) != {"label", "argv"}:
            raise ValueError("Each job must contain exactly label and argv")
        label, argv = job["label"], job["argv"]
        if (not isinstance(label, str) or not 0 < len(label) <= 160 or label in labels
                or any(ord(char) < 32 for char in label)):
            raise ValueError("Job labels must be unique nonempty single-line strings")
        if (not isinstance(argv, list) or not argv or any(not isinstance(arg, str) or
                any(ord(char) < 32 for char in arg) for arg in argv) or not argv[0]):
            raise ValueError("argv must be a nonempty literal string array without control characters")
        executable = Path(argv[0])
        if executable.is_absolute() or any(separator in argv[0] for separator in ("/", "\\")):
            executable = (executable if executable.is_absolute() else cwd / executable).resolve(strict=True)
        else:
            located = shutil.which(argv[0])
            if not located:
                raise ValueError("Job executable not found: " + argv[0])
            executable = Path(located).resolve(strict=True)
        if not executable.is_file():
            raise ValueError("Job executable is not a file")
        labels.add(label)
        normalized = [str(executable), *argv[1:]]
        slug = re.sub(r"[^A-Za-z0-9_-]+", "-", label).strip("-")[:70] or "job"
        result.append({"phase": phase, "number": number, "label": label, "argv": normalized,
                       "preview_windows_command": subprocess.list2cmdline(normalized),
                       "log_prefix": f"phase-{phase:02d}-job-{number:03d}-{slug}", "status": "pending"})
    return result


class _BasicLimits(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
                ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]


class _IoCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in ("ReadOperationCount", "WriteOperationCount",
                "OtherOperationCount", "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _BasicLimits), ("IoInfo", _IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


class OwnedProcess:
    """A Windows Job Object contains only this child and its descendants."""
    def __init__(self, argv, cwd, stdout, stderr):
        self.process, self.job, self.kernel = None, None, None
        if os.name == "nt":
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            kernel.CreateJobObjectW.restype = wintypes.HANDLE
            kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
            kernel.SetInformationJobObject.restype = wintypes.BOOL
            kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            kernel.AssignProcessToJobObject.restype = wintypes.BOOL
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel.CloseHandle.restype = wintypes.BOOL
            self.kernel = kernel
            self.job = kernel.CreateJobObjectW(None, None)
            if not self.job:
                raise OSError("Could not create child process containment")
            limits = _ExtendedLimits()
            limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
            if not kernel.SetInformationJobObject(self.job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
                self.close()
                raise OSError("Could not configure child process containment")
        options = {"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
        try:
            self.process = subprocess.Popen(argv, cwd=cwd, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL,
                                            shell=False, **options)
            if self.job and not self.kernel.AssignProcessToJobObject(self.job, wintypes.HANDLE(int(self.process._handle))):
                self.process.terminate()
                self.process.wait(timeout=5)
                raise OSError("Could not contain this child; it was stopped before continuing")
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.job is not None:
            self.kernel.CloseHandle(self.job)
            self.job = None
        if self.process is not None and self.process.poll() is None:
            if os.name == "nt":
                self.process.terminate()
            else:
                try:
                    os.killpg(self.process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if os.name != "nt":
                    try:
                        os.killpg(self.process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                else:
                    self.process.kill()
                self.process.wait(timeout=5)


class _MemoryStatus(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                *[(name, ctypes.c_ulonglong) for name in ("ullTotalPhys", "ullAvailPhys", "ullTotalPageFile",
                   "ullAvailPageFile", "ullTotalVirtual", "ullAvailVirtual", "ullAvailExtendedVirtual")]]


class SystemSampler:
    def __init__(self, destination, interval=5):
        self.destination, self.interval = destination, interval
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.run, name="batch-system-sampler", daemon=True)
        self.samples, self.previous = [], None

    def sample(self):
        if os.name != "nt":
            return {"at": utc(), "status": "unavailable", "reason": "Windows counters unavailable"}
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        idle, system, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        kernel.GetSystemTimes.argtypes = [ctypes.POINTER(wintypes.FILETIME)] * 3
        kernel.GetSystemTimes.restype = wintypes.BOOL
        kernel.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(_MemoryStatus)]
        kernel.GlobalMemoryStatusEx.restype = wintypes.BOOL
        if not kernel.GetSystemTimes(ctypes.byref(idle), ctypes.byref(system), ctypes.byref(user)):
            raise OSError("GetSystemTimes failed")
        integer = lambda value: (value.dwHighDateTime << 32) | value.dwLowDateTime
        current = integer(idle), integer(system) + integer(user)
        cpu = None
        if self.previous is not None and current[1] > self.previous[1]:
            cpu = max(0, min(100, 100 * (1 - (current[0] - self.previous[0]) / (current[1] - self.previous[1]))))
        self.previous = current
        memory = _MemoryStatus()
        memory.dwLength = ctypes.sizeof(memory)
        if not kernel.GlobalMemoryStatusEx(ctypes.byref(memory)):
            raise OSError("GlobalMemoryStatusEx failed")
        return {"at": utc(), "status": "ok", "cpu_percent": cpu, "memory_percent": memory.dwMemoryLoad,
                "physical_total_bytes": memory.ullTotalPhys, "physical_available_bytes": memory.ullAvailPhys}

    def run(self):
        with self.destination.open("x", encoding="utf-8") as stream:
            while not self.stop_event.is_set():
                try:
                    value = self.sample()
                except Exception as error:
                    value = {"at": utc(), "status": "error", "type": type(error).__name__}
                self.samples.append(value)
                stream.write(json.dumps(value, allow_nan=False) + "\n")
                stream.flush()
                self.stop_event.wait(self.interval)

    def summary(self):
        cpu = [value["cpu_percent"] for value in self.samples if value.get("cpu_percent") is not None]
        memory = [value["memory_percent"] for value in self.samples if value.get("memory_percent") is not None]
        return {"samples": len(self.samples), "cpu_samples": len(cpu),
                "cpu_mean_percent": sum(cpu) / len(cpu) if cpu else None, "cpu_max_percent": max(cpu) if cpu else None,
                "memory_max_percent": max(memory) if memory else None,
                "scope": "sampled total desktop load, including unrelated work; not isolated engine CPU"}


def run(arguments):
    cwd, output = arguments.cwd.resolve(strict=True), arguments.output.resolve()
    files = [arguments.jobs, *arguments.then_jobs]
    phases = [read_jobs(path.resolve(strict=True), cwd, index) for index, path in enumerate(files, 1)]
    output.mkdir(parents=True, exist_ok=False)
    result = {"schema": "regicide.experiment-batch.v1", "started_at": utc(), "cwd": str(cwd),
              "workers": arguments.workers, "dry_run": arguments.dry_run,
              "phase_barrier": "All jobs in phase N terminate before any job in phase N+1 starts; failures are retained",
              "jobs_files": [str(path.resolve()) for path in files], "jobs": [job for phase in phases for job in phase],
              "status": "dry_run" if arguments.dry_run else "running"}
    target = output / "result.json"
    if arguments.dry_run:
        for job in result["jobs"]:
            job["status"] = "planned_dry_run"
        result.update(finished_at=utc(), launched_processes=0)
        write_json(target, result)
        return result
    sampler = SystemSampler(output / "system-samples.jsonl") if arguments.sample_system else None
    active = {}
    interrupted = False
    runner_error = None
    if sampler:
        sampler.thread.start()
    write_json(target, result)
    try:
        for phase in phases:
            pending = list(phase)
            while pending or active:
                while pending and len(active) < arguments.workers:
                    job = pending.pop(0)
                    out_path = output / (job["log_prefix"] + ".stdout.log")
                    err_path = output / (job["log_prefix"] + ".stderr.log")
                    job.update(started_at=utc(), stdout=str(out_path), stderr=str(err_path))
                    out_stream, err_stream = out_path.open("xb"), err_path.open("xb")
                    try:
                        child = OwnedProcess(job["argv"], cwd, out_stream, err_stream)
                        job.update(status="running", pid=child.process.pid)
                        active[job["log_prefix"]] = (job, child, time.monotonic(), out_stream, err_stream)
                        print(json.dumps({"event": "job_start", "phase": job["phase"], "label": job["label"], "pid": job["pid"]}), flush=True)
                    except Exception as error:
                        job.update(status="launch_failed", finished_at=utc(), exit_code=None, error=type(error).__name__ + ": " + str(error))
                        out_stream.close()
                        err_stream.close()
                    write_json(target, result)
                for key, (job, child, started, out_stream, err_stream) in list(active.items()):
                    elapsed = time.monotonic() - started
                    timed_out = bool(arguments.job_timeout and elapsed > arguments.job_timeout)
                    if timed_out:
                        child.close()
                    code = child.process.poll()
                    if code is None:
                        continue
                    child.close()
                    out_stream.close()
                    err_stream.close()
                    job.update(status="timed_out" if timed_out else "completed" if code == 0 else "failed",
                               exit_code=code, elapsed_seconds=round(elapsed, 3), finished_at=utc())
                    del active[key]
                    print(json.dumps({"event": "job_end", "phase": job["phase"], "label": job["label"],
                                      "status": job["status"], "exit_code": code, "elapsed_seconds": job["elapsed_seconds"]}), flush=True)
                    write_json(target, result)
                if pending or active:
                    time.sleep(.2)
    except KeyboardInterrupt:
        interrupted = True
    except BaseException as error:
        runner_error = type(error).__name__ + ": " + str(error)
        result["runner_error"] = runner_error
    finally:
        for job, child, started, out_stream, err_stream in active.values():
            try:
                child.close()
                job["exit_code"] = child.process.poll()
            except Exception as error:
                job["cleanup_error"] = type(error).__name__
            finally:
                out_stream.close()
                err_stream.close()
            job.update(status="cancelled", finished_at=utc(), elapsed_seconds=round(time.monotonic() - started, 3))
        for job in result["jobs"]:
            if job["status"] == "pending":
                job.update(status="not_started_after_interrupt" if interrupted else "not_started_after_runner_error", finished_at=utc())
        if sampler:
            sampler.stop_event.set()
            sampler.thread.join(timeout=2)
            result["system_load"] = sampler.summary()
        failures = [job for job in result["jobs"] if job["status"] != "completed"]
        result.update(finished_at=utc(), status="interrupted" if interrupted else "failed" if failures or runner_error else "completed",
                      completed_jobs=sum(job["status"] == "completed" for job in result["jobs"]),
                      failed_or_not_started_jobs=len(failures), launched_processes=sum("pid" in job for job in result["jobs"]))
        write_json(target, result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", type=Path, required=True)
    parser.add_argument("--then-jobs", type=Path, action="append", default=[], help="Next phase; starts after every earlier-phase child terminates")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cwd", type=Path, default=ROOT)
    parser.add_argument("--workers", type=int, default=2, choices=(1, 2, 3))
    parser.add_argument("--job-timeout", type=float, default=3600, help="Per child wall seconds; 0 disables this outer limit")
    parser.add_argument("--sample-system", action="store_true", help="Write Windows total CPU/memory samples every five seconds")
    parser.add_argument("--dry-run", action="store_true", help="Validate argv and write the plan; start no subprocess or sampler")
    arguments = parser.parse_args(argv)
    if arguments.job_timeout < 0:
        parser.error("job-timeout cannot be negative")
    result = run(arguments)
    print(json.dumps({"status": result["status"], "jobs": len(result["jobs"]),
                      "launched_processes": result["launched_processes"], "output": str(arguments.output.resolve())}), flush=True)
    return 0 if result["status"] in ("completed", "dry_run") else 1


if __name__ == "__main__":
    raise SystemExit(main())
