@echo off
chcp 65001 >nul
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "C:\Users\hanso\.codex\.chatgpt-projects\g-p-6a8b058617088191ac7cb44895558f31\Regicide-m1-integration"
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\board.cpp /Fobuild-gambit-forcing\board.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\search.cpp /Fobuild-gambit-forcing\search.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\evaluation.cpp /Fobuild-gambit-forcing\evaluation.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c tests\reference_evaluation_v054.cpp /Fobuild-gambit-forcing\reference_evaluation_v054.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c tests\reference_evaluation_v056.cpp /Fobuild-gambit-forcing\reference_evaluation_v056.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\transposition.cpp /Fobuild-gambit-forcing\transposition.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\see.cpp /Fobuild-gambit-forcing\see.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\neural.cpp /Fobuild-gambit-forcing\neural.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\nnue.cpp /Fobuild-gambit-forcing\nnue.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /GL- /DNDEBUG /Iinclude /c tests\reference_neural_v063.cpp /Fobuild-gambit-forcing\reference_neural_v063.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\uci.cpp /Fobuild-gambit-forcing\uci.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude src\main.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj build-gambit-forcing\uci.obj /Fobuild-gambit-forcing\main.obj /Febuild-gambit-forcing\regicide.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\rules_tests.cpp build-gambit-forcing\board.obj /Fobuild-gambit-forcing\rules_tests.obj /Febuild-gambit-forcing\regicide_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\search_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\search_tests.obj /Febuild-gambit-forcing\regicide_search_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\queen_defense_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\queen_defense_tests.obj /Febuild-gambit-forcing\regicide_queen_defense_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\forcing_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\forcing_tests.obj /Febuild-gambit-forcing\regicide_forcing_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\evaluation_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\reference_evaluation_v054.obj build-gambit-forcing\reference_evaluation_v056.obj /Fobuild-gambit-forcing\evaluation_tests.obj /Febuild-gambit-forcing\regicide_evaluation_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\board_state_tests.cpp build-gambit-forcing\board.obj /Fobuild-gambit-forcing\board_state_tests.obj /Febuild-gambit-forcing\regicide_board_state_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\transposition_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\transposition_tests.obj /Febuild-gambit-forcing\regicide_transposition_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\see_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\see_tests.obj /Febuild-gambit-forcing\regicide_see_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\neural_tests.cpp build-gambit-forcing\reference_neural_v063.obj build-gambit-forcing\board.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\neural_tests.obj /Febuild-gambit-forcing\regicide_neural_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\nnue_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\regicide_nnue_tests.obj /Febuild-gambit-forcing\regicide_nnue_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\neural_model_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\regicide_neural_model_tests.obj /Febuild-gambit-forcing\regicide_neural_model_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\leaf_observer_tests.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\regicide_leaf_observer_tests.obj /Febuild-gambit-forcing\regicide_leaf_observer_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\collect_search_leaves.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\collect_search_leaves.obj /Febuild-gambit-forcing\regicide_leaf_data.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\evaluation_benchmark.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\regicide_evaluation_benchmark.obj /Febuild-gambit-forcing\regicide_evaluation_benchmark.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\neural_incremental_benchmark.cpp build-gambit-forcing\board.obj build-gambit-forcing\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing\regicide_neural_incremental_benchmark.obj /Febuild-gambit-forcing\regicide_neural_incremental_benchmark.exe
if errorlevel 1 exit /b 1


exit /b %errorlevel%