"""Twenty predeclared native-only consistency probes on disclosed positions."""
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import sys
import chess
import chess.engine

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests"))
from tactical_horizon_validation import query, sha, write

OUT = Path(__file__).resolve().parent
BINARY = ROOT / "build-gambit-forcing/screen-002/candidate-ae0a960c.exe"
FEN = "r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31"
ESCAPE_HISTORY = ["a4a3", "h4h8", "f8f7", "h8h7"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def main():
    if (OUT / "report.json").exists():
        raise FileExistsError("Preserve prior diagnostic output")
    original = chess.Board(FEN)
    escaped = original.copy(stack=True)
    for move in ESCAPE_HISTORY:
        escaped.push_uci(move)
    specs = []
    for move in ["a4a3", "f5e5", "c6e4", "c6c5", "d6d5"]:
        specs.append({"scope": "initial-root", "history": [], "root": move, "depth": 5})
    for move in escaped.legal_moves:
        specs.append({"scope": "checked-escape", "history": ESCAPE_HISTORY,
                      "root": move.uci(), "depth": 3})
    specs += [{"scope": "initial-free", "history": [], "root": None, "depth": 5},
              {"scope": "initial-shallow-a3", "history": [], "root": "a4a3", "depth": 1}]
    assert len(specs) == 10
    report = {"schema": "regicide.forcing-native-consistency.v1", "started_utc": utc(),
        "initial_fen": FEN, "specs": specs, "node_cap": 1000000,
        "scope": "Twenty native-only probes. Fixed depth differs across root groups; no external engine executed or supplied as input.",
        "binary_sha256": sha(BINARY), "source_sha256": sha(Path(__file__)),
        "query_helper_sha256": sha(ROOT / "tests/tactical_horizon_validation.py"),
        "rows": [], "errors": []}
    write(OUT / "predeclared.json", report)
    logger = logging.getLogger("chess.engine")
    old_level = logger.level
    handler = logging.FileHandler(OUT / "raw-uci.log", encoding="utf-8")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    try:
        for index, spec in enumerate(specs):
            board = original.copy(stack=True)
            for move in spec["history"]:
                board.push_uci(move)
            roots = [chess.Move.from_uci(spec["root"])] if spec["root"] else None
            for enabled in ([False, True] if index % 2 == 0 else [True, False]):
                value = query(BINARY, board, chess.engine.Limit(depth=spec["depth"], nodes=1000000),
                              "UseQuiescenceForcing", enabled, roots)
                complete = value["execution_valid"] and value.get("completed_line", {}).get("depth") == spec["depth"]
                row = {"spec": spec, "forcing": enabled, "requested_depth_completed": complete, "query": value}
                report["rows"].append(row)
                if not complete:
                    report["errors"].append({"spec": spec, "forcing": enabled, "error": value.get("error"),
                                             "status": "requested_depth_incomplete"})
                write(OUT / "report.json", report)
                line = value.get("completed_line") or {}
                print(json.dumps({"scope": spec["scope"], "root": spec["root"], "forcing": enabled,
                    "requested_depth": spec["depth"], "depth": line.get("depth"), "cp": line.get("cp_root"),
                    "nodes": value.get("final_total_nodes"), "pv": line.get("pv_uci"), "complete": complete}), flush=True)
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
        handler.close()
        report.update(finished_utc=utc(), binary_unchanged=sha(BINARY) == report["binary_sha256"],
                      source_unchanged=sha(Path(__file__)) == report["source_sha256"])
        report["execution_valid"] = (len(report["rows"]) == 20 and not report["errors"]
            and report["binary_unchanged"] and report["source_unchanged"])
        write(OUT / "report.json", report)
    return 0 if report["execution_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
