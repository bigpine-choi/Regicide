@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude build-gambit-forcing-next\fixture_probe.cpp build-gambit-forcing-next\candidate\search.obj build-gambit-forcing\board.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing-next\fixture_probe.obj /Febuild-gambit-forcing-next\fixture_probe.exe
exit /b %errorlevel%
