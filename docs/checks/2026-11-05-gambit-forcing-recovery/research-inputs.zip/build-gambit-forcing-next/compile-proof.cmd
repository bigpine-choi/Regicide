@echo off
chcp 65001 >nul
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "C:\Users\hanso\.codex\.chatgpt-projects\g-p-6a8b058617088191ac7cb44895558f31\Regicide-m1-integration"
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude build-gambit-forcing-next\proof_probe.cpp build-gambit-forcing\board.obj /Fobuild-gambit-forcing-next\proof_probe.obj /Febuild-gambit-forcing-next\proof_probe.exe
exit /b %errorlevel%
