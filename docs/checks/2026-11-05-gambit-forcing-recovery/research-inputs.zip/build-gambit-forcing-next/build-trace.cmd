@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\trace_gambit_leaf.cpp build-gambit-forcing\board.obj build-gambit-forcing-next\candidate\search.obj build-gambit-forcing\evaluation.obj build-gambit-forcing\transposition.obj build-gambit-forcing\see.obj build-gambit-forcing\neural.obj build-gambit-forcing\nnue.obj /Fobuild-gambit-forcing-next\candidate\trace_gambit_leaf.obj /Febuild-gambit-forcing-next\candidate\regicide_trace_gambit_leaf.exe
exit /b %errorlevel%