#include "regicide/checking_proof.hpp"

#include <chrono>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace regicide;
int main() {
    const char* fen = "r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31";
    const std::vector<std::vector<const char*>> histories{
        {}, {"a4a3"}, {"a4a3", "h4h8", "f8f7", "h8h7", "f7f8"}};
    const std::vector<std::string> names{"initial", "after_a3", "after_return_kf8"};
    for (std::size_t i = 0; i < histories.size(); ++i) {
        Board board(fen);
        for (const char* move : histories[i]) board.play(move);
        const Board saved = board;
        std::uint64_t visits = 0;
        const auto start = std::chrono::steady_clock::now();
        const auto result = can_force_draw(board, Color::white, 32, 100000, [&] { ++visits; });
        const double elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - start).count();
        if (!(board == saved) || visits != result.nodes) throw std::runtime_error("history/accounting changed");
        Board replay = saved;
        for (Move move : result.witness) replay.play(move);
        std::cout << "{\"case\":\"" << names[i] << "\",\"proven\":" << (result.proven ? "true" : "false")
                  << ",\"budget_exhausted\":" << (result.budget_exhausted ? "true" : "false")
                  << ",\"nodes\":" << result.nodes << ",\"deepest_ply\":" << result.deepest_ply
                  << ",\"elapsed_ms\":" << elapsed << ",\"board_preserved\":true,\"witness\":[";
        for (std::size_t j = 0; j < result.witness.size(); ++j) {
            if (j) std::cout << ',';
            std::cout << '"' << result.witness[j].uci() << '"';
        }
        std::cout << "]}\n" << std::flush;
    }
}
