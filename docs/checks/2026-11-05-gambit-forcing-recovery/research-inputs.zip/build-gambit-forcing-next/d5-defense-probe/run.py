"""Predeclared native checks first, then two separate SF diagnostic PVs."""
from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import chess
import chess.engine

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests"))
from tactical_horizon_validation import query, sf_audit, sha, write

OUT = Path(__file__).resolve().parent
NATIVE = ROOT / "build-gambit-forcing-next/candidate/regicide.exe"
SF = ROOT / "build-m2-opponents/stockfish18/package/stockfish/stockfish-windows-x86-64.exe"
FEN = "r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31"
HISTORY = ["d6d5", "h4h8", "f8f7", "h8h7", "f7g8", "h7h8", "g8f7", "h8h7", "f7g6"]


def board(history):
    value = chess.Board(FEN)
    for move in history:
        value.push_uci(move)
    return value


def main():
    if (OUT / "report.json").exists():
        raise FileExistsError("Preserve prior diagnostic output")
    cases = {"after-d5": ["d6d5"], "after-specified-checking-line": HISTORY}
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in [NATIVE, SF, Path(__file__),
        ROOT / "src/search.cpp", ROOT / "include/regicide/search.hpp",
        ROOT / "tests/tactical_horizon_validation.py"]}
    report = {"schema": "regicide.d5-diagnostic-pv.v1", "started_utc": datetime.now(timezone.utc).isoformat(),
        "initial_fen": FEN, "histories": cases, "hashes": hashes,
        "native_before_external": True, "native": [], "external": {},
        "scope": "Two native choices at the same declared long-history root, depths1/3; afterward SF free PVs at two fixed roots. SF moves and scores never become native selection inputs."}
    write(OUT / "predeclared.json", report)
    logger = logging.getLogger("chess.engine")
    level = logger.level
    handler = logging.FileHandler(OUT / "raw-uci.log", encoding="utf-8")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    try:
        for depth in (1, 3):
            result = query(NATIVE, board(HISTORY), chess.engine.Limit(depth=depth, nodes=1000000),
                           "UseQuiescenceForcing", True)
            report["native"].append({"case": "after-specified-checking-line", "depth": depth, "query": result})
            write(OUT / "report.json", report)
            print(json.dumps({"native_depth": depth, "result": result.get("completed_line"),
                              "execution_valid": result["execution_valid"]}), flush=True)
        report["native_selection_finished_utc"] = datetime.now(timezone.utc).isoformat()
        write(OUT / "report.json", report)
        flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        engine = chess.engine.SimpleEngine.popen_uci([str(SF)], timeout=10, **flags)
        try:
            settings = {"Threads": 1, "Hash": 32, "UCI_LimitStrength": False, "Skill Level": 20}
            engine.configure(settings)
            report["sf_settings"] = {"options": settings, "depth_cap": 18, "time_cap_seconds": 1}
            for name, history in cases.items():
                value = sf_audit(engine, board(history), [], seconds=1, depth=18)
                report["external"][name] = value
                write(OUT / "report.json", report)
                print(json.dumps({"external_case": name, "depth": value.get("depth"),
                                  "free": value.get("scores", {}).get("free")}), flush=True)
        finally:
            engine.quit()
            report["sf_exit_code"] = engine.returncode.result(timeout=3)
            engine.close()
    finally:
        logger.removeHandler(handler)
        logger.setLevel(level)
        handler.close()
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        report["files_unchanged"] = all(sha(ROOT / name) == digest for name, digest in hashes.items())
        report["execution_valid"] = (len(report["native"]) == 2 and all(row["query"]["execution_valid"]
            and row["query"]["completed_line"]["depth"] == row["depth"] for row in report["native"])
            and len(report["external"]) == 2 and report.get("sf_exit_code") == 0 and report["files_unchanged"])
        write(OUT / "report.json", report)
    return 0 if report["execution_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
