"""Audit saved own-engine choices at one disclosed root; no native search."""
from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import chess
import chess.engine

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests"))
from tactical_horizon_validation import sf_audit, sha, write

OUT = Path(__file__).resolve().parent
SF = ROOT / "build-m2-opponents/stockfish18/package/stockfish/stockfish-windows-x86-64.exe"
NATIVE_RECORD = ROOT / "build-gambit-forcing-next/rook-horizon.json"
FEN = "r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31"
MOVES = ["c6d5", "a4a3", "d6d5", "f5e5", "c6e4"]


def main():
    if (OUT / "report.json").exists():
        raise FileExistsError("Preserve prior audit")
    board = chess.Board(FEN)
    record = json.loads(NATIVE_RECORD.read_text(encoding="utf-8"))
    report = {"schema": "regicide.rook-horizon-root-audit.v1", "started_utc": datetime.now(timezone.utc).isoformat(),
        "initial_fen": FEN, "root_moves": MOVES, "native_record_sha256": sha(NATIVE_RECORD),
        "native_binary_sha256": record["binary_sha256"], "sf_sha256": sha(SF),
        "source_sha256": sha(Path(__file__)),
        "scope": "Saved native choices first; six external-only queries. Audit output never supplied to actual native selection.",
        "settings": {"Threads": 1, "Hash": 32, "UCI_LimitStrength": False, "Skill Level": 20},
        "depth_cap": 18, "seconds_cap": 1}
    write(OUT / "predeclared.json", report)
    logger = logging.getLogger("chess.engine")
    old = logger.level
    handler = logging.FileHandler(OUT / "raw-uci.log", encoding="utf-8")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    engine = chess.engine.SimpleEngine.popen_uci([str(SF)], timeout=10, **flags)
    try:
        engine.configure(report["settings"])
        report["audit"] = sf_audit(engine, board, MOVES, seconds=1, depth=18)
    finally:
        engine.quit()
        report["sf_exit_code"] = engine.returncode.result(timeout=3)
        engine.close()
        logger.removeHandler(handler)
        logger.setLevel(old)
        handler.close()
    report["native_record_unchanged"] = sha(NATIVE_RECORD) == report["native_record_sha256"]
    report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    report["execution_valid"] = (report["sf_exit_code"] == 0 and report["native_record_unchanged"]
        and report["audit"]["status"] == "common_exact_depth")
    write(OUT / "report.json", report)
    audit = report["audit"]
    print(json.dumps({"depth": audit.get("depth"), "status": audit["status"],
        "exit_code": report["sf_exit_code"], "scores": {key: {"cp_black": value["cp_root"],
            "mate_black": value["mate_root"], "pv_uci": value["pv_uci"]}
            for key, value in audit.get("scores", {}).items()}, "loss_cp": audit.get("loss_cp")}), flush=True)
    return 0 if report["execution_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
