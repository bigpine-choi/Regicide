"""Observe actual evaluations around the disclosed Kf8 checking cycle."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BINARY = ROOT / "build-gambit-forcing-next/candidate/regicide_trace_gambit_leaf.exe"
FEN = "r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31"
HISTORY = "a4a3 h4h8 f8f7 h8h7"
TARGETS = {
    "material-pv": "f7f8 e4e7 a3b2 c3b2",
    "cycle-before-extra-check": "f7f8 h7h8 f8f7 h8h7 f7f8",
    "cycle-after-extra-check": "f7f8 h7h8 f8f7 h8h7 f7f8 h7h8 f8f7",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    if (OUT / "report.json").exists():
        raise FileExistsError("Preserve the prior trace")
    tracked = [BINARY, Path(__file__), ROOT / "scripts/trace_gambit_leaf.cpp",
        ROOT / "src/search.cpp", ROOT / "include/regicide/search.hpp",
        ROOT / "build-gambit-forcing-next/candidate/search.obj"]
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in tracked}
    report = {"schema": "regicide.kf8-leaf-observation.v1", "started_utc": datetime.now(timezone.utc).isoformat(),
        "hashes": hashes, "initial_fen": FEN, "history": HISTORY.split(),
        "targets": TARGETS, "depth": 3, "node_cap": 5000000, "rows": [],
        "scope": "Actual matching evaluator invocations only; no causal attribution of the final root value, no external engine queries."}
    write(OUT / "predeclared.json", report)
    flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    for name, target in TARGETS.items():
        stdin = "\t".join([FEN, HISTORY, "f7f8", target]) + "\n"
        (OUT / (name + ".tsv")).write_text(stdin, encoding="utf-8")
        for forcing in (False, True):
            command = [str(BINARY), "--depth", "3", "--nodes", "5000000"] + (["--forcing"] if forcing else [])
            run = subprocess.run(command, input=stdin, text=True, encoding="utf-8", capture_output=True,
                                 timeout=30, **flags)
            output = OUT / (name + ("-on.json" if forcing else "-off.json"))
            output.write_text(run.stdout, encoding="utf-8")
            value = json.loads(run.stdout) if run.returncode == 0 else None
            row = {"name": name, "forcing": forcing, "command": command,
                "returncode": run.returncode, "stderr": run.stderr, "output": output.name, "trace": value}
            report["rows"].append(row)
            write(OUT / "report.json", report)
            print(json.dumps({"name": name, "forcing": forcing, "exit": run.returncode,
                "matches": value["match_count"] if value else None,
                "search": value["search"] if value else None,
                "observations": value["matches"] if value else None}), flush=True)
    report["sources_unchanged"] = all(sha(ROOT / name) == value for name, value in hashes.items())
    report["execution_valid"] = (len(report["rows"]) == 6 and report["sources_unchanged"]
        and all(row["returncode"] == 0 and row["trace"]["requested_iteration_completed"]
                and row["trace"]["position_unchanged"] for row in report["rows"]))
    report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    write(OUT / "report.json", report)
    return 0 if report["execution_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
