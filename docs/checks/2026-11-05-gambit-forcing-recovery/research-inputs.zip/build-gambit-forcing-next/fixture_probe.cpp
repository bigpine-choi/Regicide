#include "regicide/search.hpp"
#include <iostream>
using namespace regicide;
int main() {
    Board before("r4k2/2p5/1pqp4/5r2/p3R2R/2B3P1/PP3P1P/6K1 b - - 3 31");
    for (const char* move : {"d6d5", "h4h8", "f8f7", "h8h7", "f7g8", "h7h8", "g8f7", "h8h7"}) before.play(move);
    Board after = before; after.play("f7g6");
    for (bool enabled : {false, true}) for (bool before_move : {false, true}) for (int depth : {1,2,3}) {
        SearchOptions options;
        options.quiescence_forcing = enabled;
        options.piece_activity = true;
        options.hash_mb = 1;
        if (before_move) options.root_moves = std::vector<Move>{Move::from_uci("f7g6")};
        const auto result = search(before_move ? before : after, {.depth=depth, .nodes=1000000}, nullptr, {}, options);
        std::cout << "on " << enabled << " beforeKg6 " << before_move << " D " << depth
                  << " completed " << result.depth << " cp " << result.score << " nodes " << result.nodes
                  << " threats " << result.quiet_threat_extensions << " defenses " << result.defensive_qnodes
                  << " checks " << result.forcing_checks << " pv";
        for (Move move : result.pv) std::cout << ' ' << move.uci();
        std::cout << '\n' << std::flush;
    }
}
