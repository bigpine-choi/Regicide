"""One preregistered16-game own-engine screen; no live app activation."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if (OUT / "protocol.json").exists():
        raise FileExistsError("Preserve the existing match attempt")
    inputs = OUT / "inputs"
    inputs.mkdir()
    original = {"baseline": ROOT / "build-gambit-forcing/regicide.exe",
                "candidate": ROOT / "build-gambit-forcing-next-final/regicide.exe"}
    copied = {}
    for arm, path in original.items():
        copied[arm] = inputs / (arm + ".exe")
        shutil.copy2(path, copied[arm])
    options = {"UsePieceActivity": True, "Hash": 16, "UsePositionalEvaluation": True,
               "UseNeuralEvaluation": False, "UseNNUEEvaluation": False,
               "UseQuiescenceForcing": False}
    candidate_options = {**options, "UseQuiescenceForcing": True}
    commits = {"baseline": "7a3ca1cb474dc5f806a8cdd09a2a7079bda36125",
               "candidate": "6aa8319f51919cd12ae336c3dd5747c67f540d2d"}
    command = [sys.executable, str(ROOT / "scripts/compare_engines.py"),
        str(copied["baseline"]), str(copied["candidate"]), "--pgn", str(OUT / "match.pgn"),
        "--movetime", "100", "--opening-count", "8", "--max-plies", "320", "--draw-policy", "claim",
        "--baseline-commit", commits["baseline"], "--candidate-commit", commits["candidate"],
        "--baseline-options", json.dumps(options), "--candidate-options", json.dumps(candidate_options)]
    protocol = {"schema": "regicide.forcing-recovery-core-match.v1",
        "started_utc": datetime.now(timezone.utc).isoformat(), "commits": commits,
        "original_binaries": {arm: str(path) for arm, path in original.items()},
        "sha256": {arm: sha(path) for arm, path in copied.items()},
        "opening_file_sha256": sha(ROOT / "tests/data/comparison_openings.json"),
        "harness_sha256": sha(ROOT / "scripts/compare_engines.py"),
        "options": {"baseline": options, "candidate": candidate_options},
        "schedule": "All8 pre-existing openings, paired colors,16games,100ms request,320ply cap including opening, claim available threefold/50move draws for both sides.",
        "scope": "Native UCI core only, not production HumanGame gambit policy, Elo, or live activation.",
        "command": command}
    (OUT / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    with (OUT / "stdout.txt").open("w", encoding="utf-8") as stdout, (OUT / "stderr.txt").open("w", encoding="utf-8") as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, **flags)
    protocol["finished_utc"] = datetime.now(timezone.utc).isoformat()
    protocol["returncode"] = result.returncode
    protocol["copied_binaries_unchanged"] = all(sha(path) == protocol["sha256"][arm] for arm, path in copied.items())
    (OUT / "receipt.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"returncode": result.returncode, "copied_binaries_unchanged": protocol["copied_binaries_unchanged"]}), flush=True)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
