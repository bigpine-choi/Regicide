@echo off
chcp 65001 >nul
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "C:\Users\hanso\.codex\.chatgpt-projects\g-p-6a8b058617088191ac7cb44895558f31\Regicide-m1-integration"
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\board.cpp /Fobuild-gambit-forcing-next-final\board.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\search.cpp /Fobuild-gambit-forcing-next-final\search.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\evaluation.cpp /Fobuild-gambit-forcing-next-final\evaluation.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c tests\reference_evaluation_v054.cpp /Fobuild-gambit-forcing-next-final\reference_evaluation_v054.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c tests\reference_evaluation_v056.cpp /Fobuild-gambit-forcing-next-final\reference_evaluation_v056.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\transposition.cpp /Fobuild-gambit-forcing-next-final\transposition.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\see.cpp /Fobuild-gambit-forcing-next-final\see.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\neural.cpp /Fobuild-gambit-forcing-next-final\neural.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\nnue.cpp /Fobuild-gambit-forcing-next-final\nnue.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /GL- /DNDEBUG /Iinclude /c tests\reference_neural_v063.cpp /Fobuild-gambit-forcing-next-final\reference_neural_v063.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude /c src\uci.cpp /Fobuild-gambit-forcing-next-final\uci.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude src\main.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj build-gambit-forcing-next-final\uci.obj /Fobuild-gambit-forcing-next-final\main.obj /Febuild-gambit-forcing-next-final\regicide.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\rules_tests.cpp build-gambit-forcing-next-final\board.obj /Fobuild-gambit-forcing-next-final\rules_tests.obj /Febuild-gambit-forcing-next-final\regicide_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\search_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\search_tests.obj /Febuild-gambit-forcing-next-final\regicide_search_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\queen_defense_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\queen_defense_tests.obj /Febuild-gambit-forcing-next-final\regicide_queen_defense_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\forcing_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\forcing_tests.obj /Febuild-gambit-forcing-next-final\regicide_forcing_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\evaluation_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\reference_evaluation_v054.obj build-gambit-forcing-next-final\reference_evaluation_v056.obj /Fobuild-gambit-forcing-next-final\evaluation_tests.obj /Febuild-gambit-forcing-next-final\regicide_evaluation_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\board_state_tests.cpp build-gambit-forcing-next-final\board.obj /Fobuild-gambit-forcing-next-final\board_state_tests.obj /Febuild-gambit-forcing-next-final\regicide_board_state_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\transposition_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\transposition_tests.obj /Febuild-gambit-forcing-next-final\regicide_transposition_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\see_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\see_tests.obj /Febuild-gambit-forcing-next-final\regicide_see_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\neural_tests.cpp build-gambit-forcing-next-final\reference_neural_v063.obj build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\neural_tests.obj /Febuild-gambit-forcing-next-final\regicide_neural_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\nnue_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\regicide_nnue_tests.obj /Febuild-gambit-forcing-next-final\regicide_nnue_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\neural_model_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\regicide_neural_model_tests.obj /Febuild-gambit-forcing-next-final\regicide_neural_model_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude tests\leaf_observer_tests.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\regicide_leaf_observer_tests.obj /Febuild-gambit-forcing-next-final\regicide_leaf_observer_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\collect_search_leaves.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\collect_search_leaves.obj /Febuild-gambit-forcing-next-final\regicide_leaf_data.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\evaluation_benchmark.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\regicide_evaluation_benchmark.obj /Febuild-gambit-forcing-next-final\regicide_evaluation_benchmark.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Iinclude scripts\neural_incremental_benchmark.cpp build-gambit-forcing-next-final\board.obj build-gambit-forcing-next-final\search.obj build-gambit-forcing-next-final\evaluation.obj build-gambit-forcing-next-final\transposition.obj build-gambit-forcing-next-final\see.obj build-gambit-forcing-next-final\neural.obj build-gambit-forcing-next-final\nnue.obj /Fobuild-gambit-forcing-next-final\regicide_neural_incremental_benchmark.obj /Febuild-gambit-forcing-next-final\regicide_neural_incremental_benchmark.exe
if errorlevel 1 exit /b 1


exit /b %errorlevel%