@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Ibuild\repetition-cycle\include /Iinclude /c build\repetition-cycle\board.cpp /Fobuild\repetition-cycle\board.obj
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /W4 /WX /permissive- /utf-8 /O2 /DNDEBUG /Ibuild\repetition-cycle\include /Iinclude /c build\repetition-cycle\search.cpp /Fobuild\repetition-cycle\search.obj
if errorlevel 1 exit /b 1
cl /nologo /EHsc build\repetition-cycle\board.obj build\repetition-cycle\search.obj build-gambit-m2\evaluation.obj build-gambit-m2\transposition.obj build-gambit-m2\see.obj build-gambit-m2\neural.obj build-gambit-m2\nnue.obj build-gambit-m2\uci.obj build-gambit-m2\main.obj /Febuild\repetition-cycle\regicide.exe
exit /b %errorlevel%
