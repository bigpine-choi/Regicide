"""Three saved native choices only; no move selection or native searches."""
import argparse
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--stockfish", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.repo.resolve(strict=True)
    sys.path.insert(0, str(root / "tests"))
    import chess.engine
    import tactical_horizon_validation as helper
    args.stockfish = args.stockfish.resolve(strict=True)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    fixture_path = root / "tests/data/tactical_horizon_2026_11_04.json"
    fixture = next(case for case in json.loads(fixture_path.read_text(encoding="utf-8"))["cases"]
                   if case["id"] == "kings-accepted:9")
    board = helper.replay(fixture)
    before = board.fen(en_passant="fen"), list(board.move_stack)
    paths = [Path(__file__).resolve(), Path(helper.__file__), fixture_path,
             root / "tests/perpetual_check_validation.py", args.stockfish]
    hashes = {str(path): helper.sha(path) for path in paths}
    report = {"schema": "regicide.tactical-horizon-sf-reaudit.v1", "started_utc": helper.utc(),
              "fixture": fixture, "source_sha256": hashes,
              "scope": "Three-query post-selection audit of previously saved native choices; not independent games or a heldout",
              "native_selection_repeated": False, "requested": {"depth": 14, "max_seconds_per_query": 0.5,
                "roots": [None, "b1c3", "f1b5"], "clear_hash_each_query": True}, "errors": []}
    logger = logging.getLogger("chess.engine")
    level = logger.level
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(args.output_dir / "raw-uci.log", encoding="utf-8")
    logger.addHandler(handler)
    engine = None
    started = time.monotonic()
    try:
        flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        engine = chess.engine.SimpleEngine.popen_uci([str(args.stockfish)], timeout=10, **flags)
        settings = {"Threads": 1, "Hash": 32, "UCI_LimitStrength": False, "Skill Level": 20}
        engine.configure(settings)
        engine.ping()
        report.update(engine_id=dict(engine.id), configured_options=settings)
        report["audit"] = helper.sf_audit(engine, board, ["b1c3", "f1b5"], seconds=.5, depth=14)
    except Exception as error:
        report["errors"].append(f"{type(error).__name__}: {error}")
    finally:
        if engine:
            try:
                engine.quit()
            except Exception as error:
                report["errors"].append("quit: " + type(error).__name__)
                engine.close()
            try:
                code = engine.returncode.result(timeout=3)
                report.update(engine_closed=True, process_exit_code=code,
                              clean_shutdown=type(code) is int and code == 0)
            except Exception as error:
                report.update(engine_closed=False, clean_shutdown=False)
                report["errors"].append("returncode: " + type(error).__name__)
        report.update(finished_utc=helper.utc(), elapsed_ms=round((time.monotonic() - started) * 1000, 3),
                      position_unchanged=before == (board.fen(en_passant="fen"), list(board.move_stack)),
                      sources_unchanged=all(helper.sha(path) == value for path, value in hashes.items()))
        report["audit_execution_valid"] = (not report["errors"] and report.get("clean_shutdown") is True
            and report["position_unchanged"] and report["sources_unchanged"]
            and report.get("audit", {}).get("status") == "common_exact_depth")
        logger.removeHandler(handler)
        logger.setLevel(level)
        handler.close()
        helper.write(args.output_dir / "report.json", report)
    print(json.dumps({"audit_execution_valid": report["audit_execution_valid"],
        "process_exit_code": report.get("process_exit_code"), "depth": report.get("audit", {}).get("depth"),
        "loss_cp": report.get("audit", {}).get("loss_cp"), "errors": report["errors"]}))
    return 0 if report["audit_execution_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
